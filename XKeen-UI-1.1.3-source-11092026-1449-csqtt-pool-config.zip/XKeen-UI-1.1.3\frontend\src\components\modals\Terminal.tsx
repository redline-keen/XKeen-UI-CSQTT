import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { IconPlayerStopFilled, IconRefresh, IconTerminal2 } from '@tabler/icons-react'
import { useEffect, useRef, useState } from 'react'
import '@xterm/xterm/css/xterm.css'
import { FitAddon } from '@xterm/addon-fit'
import { Terminal } from '@xterm/xterm'
import { useModalContext } from '../../lib/store'

type Phase = 'idle' | 'running' | 'exited'

/** Интерактивный shell роутера: PTY-сессия живёт на бэкенде, окно лишь подключается к ней */
export function TerminalModal() {
  const { modals, dispatch } = useModalContext()
  const open = modals.showTerminalModal
  const close = () => dispatch({ type: 'SHOW_MODAL', modal: 'showTerminalModal', show: false })

  const termHostRef = useRef<HTMLDivElement | null>(null)
  const termRef = useRef<Terminal | null>(null)
  const fitRef = useRef<FitAddon | null>(null)
  const wsRef = useRef<WebSocket | null>(null)
  const resizeObsRef = useRef<ResizeObserver | null>(null)
  const runningRef = useRef(false)
  const pendingStartRef = useRef(true)

  const [phase, setPhase] = useState<Phase>('idle')

  const send = (data: object) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify(data))
  }

  useEffect(() => {
    if (!open) return

    const term = new Terminal({
      cursorBlink: true,
      fontSize: 13,
      fontFamily: "'JetBrains Mono Variable', monospace",
      convertEol: false,
      scrollback: 5000,
      theme: {
        background: '#0d1117',
        foreground: '#e6edf3',
      },
    })
    const fit = new FitAddon()
    term.loadAddon(fit)
    termRef.current = term
    fitRef.current = fit

    let disposed = false
    let rafId = 0
    let timerId: ReturnType<typeof setTimeout> | undefined

    term.onData((data) => {
      // Клавиатура xterm уходит бинарным фреймом: бэкенд пишет эти байты напрямую в PTY
      if (wsRef.current?.readyState === WebSocket.OPEN) wsRef.current.send(new TextEncoder().encode(data))
    })

    const resize = () => {
      if (!termHostRef.current) return
      fit.fit()
      send({ type: 'resize', cols: term.cols, rows: term.rows })
    }
    const observer = new ResizeObserver(resize)
    resizeObsRef.current = observer

    const mountTerminal = (host: HTMLDivElement) => {
      term.open(host)
      fit.fit()
      observer.observe(host)
      send({ type: 'resize', cols: term.cols, rows: term.rows })
      term.focus()
    }

    // Портал диалога монтирует содержимое в DOM асинхронно — позже первого рендера с open=true,
    // поэтому ждём появления узла терминала, прежде чем открывать в нём xterm.
    // rAF в фоне/свёрнутой вкладке троттлится браузером до нуля, поэтому дублируем
    // ожидание setTimeout-ом
    const waitForHost = () => {
      if (disposed) return
      const host = termHostRef.current
      if (host && document.body.contains(host)) {
        mountTerminal(host)
        return
      }
      rafId = requestAnimationFrame(waitForHost)
      timerId = setTimeout(waitForHost, 100)
    }
    waitForHost()

    const wsUrl = `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/term-ws`
    const ws = new WebSocket(wsUrl)
    ws.binaryType = 'arraybuffer'
    wsRef.current = ws

    ws.onopen = () => {
      send({ type: 'resize', cols: term.cols, rows: term.rows })
    }

    ws.onmessage = (event) => {
      if (typeof event.data === 'string') {
        try {
          const msg = JSON.parse(event.data)
          if (msg.type === 'status') {
            runningRef.current = !!msg.running
            setPhase(msg.running ? 'running' : 'idle')
            // Первый визит в модалке стартует shell; к живой сессии лишь подключаемся
            if (!msg.running && pendingStartRef.current) {
              pendingStartRef.current = false
              send({ type: 'start' })
            }
          } else if (msg.type === 'clear') {
            term.clear()
          } else if (msg.type === 'error') {
            term.write(`\r\n\x1b[31m✖ ${msg.message}\x1b[0m\r\n`)
          } else if (msg.type === 'exit') {
            runningRef.current = false
            setPhase('exited')
          }
        } catch {
          /* ignore */
        }
      } else {
        const bytes = new Uint8Array(event.data as ArrayBuffer)
        term.write(bytes)
      }
    }

    ws.onclose = () => {
      // Пишем только в живой терминал: после закрытия модалки term уже disposed
      if (termRef.current) {
        termRef.current.write('\r\n\x1b[90mСоединение с терминалом потеряно\x1b[0m\r\n')
      }
    }

    return () => {
      disposed = true
      cancelAnimationFrame(rafId)
      clearTimeout(timerId)
      observer.disconnect()
      ws.onopen = ws.onclose = ws.onerror = ws.onmessage = null
      if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) ws.close()
      wsRef.current = null
      resizeObsRef.current = null
      term.dispose()
      termRef.current = null
      fitRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const restartShell = () => {
    termRef.current?.reset()
    setPhase('running')
    send({ type: 'start' })
    termRef.current?.focus()
  }

  const stopShell = () => {
    if (phase !== 'running') return
    send({ type: 'kill' })
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && close()}>
      <DialogContent className="flex h-[85dvh]! max-w-4xl! flex-col overflow-hidden p-4 sm:p-5">
        <DialogHeader className="shrink-0 pr-10">
          <DialogTitle className="flex items-center gap-2">
            <IconTerminal2 size={24} className="text-chart-2" /> Терминал
          </DialogTitle>
          <DialogDescription>
            Интерактивный shell роутера. Ввод с клавиатуры передаётся напрямую в терминал, сессия продолжает работать после закрытия окна.
          </DialogDescription>
        </DialogHeader>

        <div className="bg-card min-h-0 flex-1 overflow-hidden rounded-lg border">
          <div ref={termHostRef} className="h-full w-full p-2" />
        </div>

        <div className="flex shrink-0 flex-wrap items-center justify-between gap-2 pt-1">
          <div className="text-muted-foreground text-xs">
            {phase === 'running' && 'Сессия активна — ввод передаётся в shell роутера'}
            {phase === 'idle' && 'Сессия не запущена'}
            {phase === 'exited' && <span className="text-red-400">Сессия завершена — можно запустить новую</span>}
          </div>
          <div className="flex items-center gap-2">
            {phase === 'running' ? (
              <TooltipProvider delayDuration={400}>
                <Tooltip>
                  <TooltipTrigger
                    render={
                      <Button variant="destructive" size="sm" onClick={stopShell}>
                        <IconPlayerStopFilled data-icon="inline-start" /> Остановить
                      </Button>
                    }
                  />
                  <TooltipContent>Завершить сессию shell</TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ) : (
              <TooltipProvider delayDuration={400}>
                <Tooltip>
                  <TooltipTrigger
                    render={
                      <Button variant="outline" size="sm" onClick={restartShell}>
                        <IconRefresh data-icon="inline-start" /> {phase === 'exited' ? 'Новая сессия' : 'Запустить'}
                      </Button>
                    }
                  />
                  <TooltipContent>Запустить shell на роутере</TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
