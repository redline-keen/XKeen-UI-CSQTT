use crate::logger::log;
use crate::types::*;
use axum::extract::State;
use axum::response::{IntoResponse, Json};
use serde::Deserialize;
use serde_json::json;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::Path;
use tokio::process::Command;

const CSQTT_CONF: &str = "/opt/etc/csqtt/csqtt.conf";
const CSQTT_INIT: &str = "/opt/etc/init.d/S99csqtt";
const CSQTT_POOL: &str = "/opt/etc/csqtt/vk_pool";

/// Правило пула-клиента: 27 воркеров на хеш, шаг 9, максимум 162.
const WORKERS_PER_HASH: u32 = 27;
const WORKERS_STEP: u32 = 9;
const MAX_HASHES: u32 = 6;
/// Автовк-клиент (0636): обёртка передаёт --allow-hash-redistribution, правило
/// 27:1 не действует, но клиентский MAX_WORKERS = 126.
const AUTOVK_MAX_WORKERS: u32 = 126;

/// Формат csqtt.conf на диске.
#[derive(PartialEq, Eq, Clone, Copy, Debug)]
enum ConfFormat {
    /// Легаси redline-keen: VK=хеши / TUN / N.
    Legacy,
    /// Пул-установщик 1341+: HASHES=число 1..6 / WORKERS / TUN_IFACE, пул vk_pool.
    Pool,
    /// Автовк-установщик 0636: HASHES=строка-хеш (звонки создаёт клиент по
    /// VK-токену), VK_MODE / WORKERS / TUN_IFACE.
    AutoVk,
}

#[derive(Deserialize)]
pub struct CsqttConfigReq {
    peer: String,
    password: String,
    /// VK-хеши через запятую (легаси- и автовк-конфиги).
    #[serde(default)]
    vk: String,
    /// Число хешей пула 1..6 (пул-формат).
    #[serde(default = "default_hashes")]
    hashes: u32,
    /// Воркеры: пул 9..162 (правило 27:1 на лету), автовк 9..126.
    #[serde(default = "default_workers")]
    workers: u32,
    #[serde(default = "default_tun")]
    tun: String,
    #[serde(default)]
    restart: bool,
}

fn default_tun() -> String {
    "csqtt0".into()
}
fn default_hashes() -> u32 {
    4
}
fn default_workers() -> u32 {
    108
}

#[derive(serde::Serialize)]
pub struct CsqttConfig {
    peer: String,
    password: String,
    /// VK-хеши через запятую (легаси и автовк); в пуле — пусто.
    vk: String,
    /// legacy | pool | autovk.
    format: String,
    legacy: bool,
    hashes: u32,
    workers: u32,
    tun: String,
    running: bool,
    /// Ссылка только там, где хеши известны (легаси и автовк); в пуле — пусто.
    link: String,
    pool_size: usize,
}

fn unquote(s: &str) -> String {
    let s = s.trim();
    // Установщики пишут KEY="value", старый UI — KEY='value'
    let s = s.strip_prefix('"').unwrap_or(s);
    let s = s.strip_suffix('"').unwrap_or(s);
    let s = s.strip_prefix('\'').unwrap_or(s);
    let s = s.strip_suffix('\'').unwrap_or(s);
    s.to_string()
}

/// Разбор KEY='value' / KEY="value" / KEY=value в порядок следования.
fn parse_conf_lines(content: &str) -> Vec<(String, String)> {
    content
        .lines()
        .filter_map(|line| {
            let line = line.trim();
            let (key, rest) = line.split_once('=')?;
            let key = key.trim().to_string();
            if key.is_empty() || key.starts_with('#') {
                return None;
            }
            Some((key, unquote(rest)))
        })
        .collect()
}

/// Формат конфига. VK= — легаси redline-keen. Иначе HASHES=число — пул
/// (1341+, там тоже есть VK_MODE, но HASHES всегда число 1..6), HASHES=строка
/// или VK_MODE без числа — автовк (0636: HASHES = хеш звонка, создаёт клиент).
fn detect_format(pairs: &[(String, String)]) -> ConfFormat {
    let get = |key: &str| {
        pairs
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.trim())
            .unwrap_or("")
    };
    if get("VK") != "" {
        return ConfFormat::Legacy;
    }
    if get("HASHES").parse::<u32>().is_ok() {
        return ConfFormat::Pool;
    }
    if get("HASHES") != "" || get("VK_MODE") == "auto_js" {
        return ConfFormat::AutoVk;
    }
    ConfFormat::Pool
}

/// Кап воркеров по правилу пула-клиента 27:1 + выравнивание к шагу 9.
fn clamp_workers(workers: u32, hashes: u32) -> u32 {
    let hashes = hashes.clamp(1, MAX_HASHES);
    let cap = hashes * WORKERS_PER_HASH;
    let mut w = workers.min(cap).max(WORKERS_STEP);
    w = w / WORKERS_STEP * WORKERS_STEP;
    if w < WORKERS_STEP {
        w = WORKERS_STEP;
    }
    w
}

/// Ссылка установщиков: csqtt://connect?v=2&host=<host>&peer=<port>&password=<p>&hashes=<h1+h2>
/// Хеши могут содержать URL-encoded ':' (%3A) и '/' (%2F), разделяются '+'.
fn build_link(peer: &str, password: &str, vk: &str) -> String {
    let (host, port) = match peer.rsplit_once(':') {
        Some((h, p)) if !h.is_empty() && !p.is_empty() => (h.to_string(), p.to_string()),
        _ => (peer.to_string(), String::new()),
    };
    let hashes = vk
        .split(',')
        .filter(|h| !h.trim().is_empty())
        .map(|h| h.trim().replace(':', "%3A").replace('/', "%2F"))
        .collect::<Vec<_>>()
        .join("+");
    format!("csqtt://connect?v=2&host={host}&peer={port}&password={password}&hashes={hashes}")
}

fn pool_size() -> usize {
    match fs::read_to_string(CSQTT_POOL) {
        Ok(content) => content
            .lines()
            .filter(|l| {
                let l = l.trim();
                !l.is_empty() && !l.starts_with('#')
            })
            .count(),
        Err(_) => 0,
    }
}

fn parse_conf(content: &str) -> CsqttConfig {
    let pairs = parse_conf_lines(content);
    let get = |key: &str| {
        pairs
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    let format = detect_format(&pairs);
    let peer = get("PEER");
    let password = get("PASSWORD");
    let (vk, hashes, workers, tun) = match format {
        ConfFormat::Legacy => {
            let n: u32 = get("N").parse().unwrap_or(108);
            let vk = get("VK");
            let vk_hashes = vk.split(',').filter(|h| !h.trim().is_empty()).count() as u32;
            (vk, vk_hashes.clamp(1, MAX_HASHES), n, get("TUN"))
        }
        ConfFormat::Pool => (
            String::new(),
            get("HASHES").parse().unwrap_or(4),
            get("WORKERS").parse().unwrap_or(108),
            get("TUN_IFACE"),
        ),
        ConfFormat::AutoVk => {
            let vk = get("HASHES");
            let vk_hashes = vk.split(',').filter(|h| !h.trim().is_empty()).count() as u32;
            let workers = get("WORKERS").parse().unwrap_or(18).min(AUTOVK_MAX_WORKERS);
            (vk, vk_hashes.clamp(1, MAX_HASHES), workers, get("TUN_IFACE"))
        }
    };
    let tun = if tun.is_empty() { default_tun() } else { tun };
    // Правило 27:1 — только в пуле; легаси- и автовк-клиенты его не знают
    // (автовк передаёт --allow-hash-redistribution, там свой потолок 126).
    let workers = match format {
        ConfFormat::Pool => clamp_workers(workers, hashes),
        ConfFormat::Legacy => workers.clamp(9, 162),
        ConfFormat::AutoVk => workers.clamp(9, AUTOVK_MAX_WORKERS),
    };
    let running = is_running();
    let link = match format {
        ConfFormat::Pool => String::new(),
        _ => build_link(&peer, &password, &vk),
    };
    CsqttConfig {
        peer,
        password,
        vk,
        format: match format {
            ConfFormat::Legacy => "legacy".into(),
            ConfFormat::Pool => "pool".into(),
            ConfFormat::AutoVk => "autovk".into(),
        },
        legacy: format == ConfFormat::Legacy,
        hashes,
        workers,
        tun,
        running,
        link,
        pool_size: pool_size(),
    }
}

fn is_running() -> bool {
    Path::new("/opt/var/run/csqtt-client.pid").exists()
        || Path::new("/var/run/csqtt.pid").exists()
        || Path::new("/proc").exists() && pid_alive("csqtt-client")
}

fn pid_alive(name: &str) -> bool {
    let Ok(entries) = fs::read_dir("/proc") else {
        return false;
    };
    for e in entries.flatten() {
        let name_ok = e.file_name().to_string_lossy().chars().all(|c| c.is_ascii_digit());
        if !name_ok {
            continue;
        }
        if fs::read_to_string(e.path().join("cmdline"))
            .is_ok_and(|cmdline| cmdline.split('\0').any(|a| a == name))
        {
            return true;
        }
    }
    false
}

fn err_response<T>(msg: impl Into<String>) -> ApiResponse<T> {
    ApiResponse {
        success: false,
        error: Some(msg.into()),
        data: None,
    }
}

pub async fn get_csqtt_config(State(_state): State<AppState>) -> impl IntoResponse {
    if !Path::new(CSQTT_CONF).exists() {
        return Json(ApiResponse::<CsqttConfig> {
            success: false,
            error: Some("CSQTT не установлен: конфиг не найден".into()),
            data: None,
        });
    }
    let Ok(content) = fs::read_to_string(CSQTT_CONF) else {
        return Json(err_response::<CsqttConfig>("Не удалось прочитать csqtt.conf"));
    };
    Json(ApiResponse {
        success: true,
        error: None,
        data: Some(parse_conf(&content)),
    })
}

/// Запись конфига: заменяем только ключи формы, остальные строки (комментарии,
/// DEVICE_ID, FINGERPRINT, CLIENT_IDS, OBFS, LISTEN, VK_MODE, CAPTCHA_MODE, …)
/// уходят в новый файл как есть — установщики рассчитывают их найти.
fn render_conf(existing: &str, updates: &[(String, String)]) -> String {
    let mut out: Vec<String> = Vec::new();
    let mut applied: Vec<bool> = vec![false; updates.len()];
    for line in existing.lines() {
        let trimmed = line.trim();
        let replaced = trimmed.split_once('=').and_then(|(k, _)| {
            let k = k.trim();
            updates.iter().position(|(key, _)| key == k)
        });
        match replaced {
            Some(idx) => {
                let (_, value) = &updates[idx];
                out.push(format!("{}=\"{}\"", updates[idx].0, value));
                applied[idx] = true;
            }
            None => out.push(line.to_string()),
        }
    }
    for (idx, (key, value)) in updates.iter().enumerate() {
        if !applied[idx] {
            out.push(format!("{}=\"{}\"", key, value));
        }
    }
    let mut text = out.join("\n");
    if !text.ends_with('\n') {
        text.push('\n');
    }
    text
}

pub async fn post_csqtt_config(
    State(_state): State<AppState>,
    Json(req): Json<CsqttConfigReq>,
) -> impl IntoResponse {
    if !Path::new(CSQTT_CONF).exists() {
        return Json(err_response::<serde_json::Value>("CSQTT не установлен: конфиг не найден"));
    }
    let Ok(existing) = fs::read_to_string(CSQTT_CONF) else {
        return Json(err_response::<serde_json::Value>("Не удалось прочитать csqtt.conf"));
    };
    let existing_pairs = parse_conf_lines(&existing);
    let format = detect_format(&existing_pairs);

    let peer = req.peer.trim().to_string();
    let password = req.password.trim().to_string();
    let vk = req.vk.trim().to_string();
    let tun = req.tun.trim().to_string();
    // В легаси/автовк HASHES из запроса — только подсказка для отображения,
    // в конфиг пишутся сами хеши. В пуле HASHES — размер пула.
    let hashes = req.hashes.clamp(1, MAX_HASHES);
    let mut workers = req.workers;

    if peer.is_empty() || !peer.contains(':') {
        return Json(err_response::<serde_json::Value>("PEER должен быть в формате host:port"));
    }
    if password.is_empty() {
        return Json(err_response::<serde_json::Value>("PASSWORD не может быть пустым"));
    }
    if format == ConfFormat::Pool && !(1..=MAX_HASHES).contains(&hashes) {
        return Json(err_response::<serde_json::Value>(format!(
            "Число хешей должно быть от 1 до {MAX_HASHES}"
        )));
    }
    let (workers_min, workers_max) = match format {
        ConfFormat::AutoVk => (9, AUTOVK_MAX_WORKERS),
        _ => (9, 162),
    };
    if !(workers_min..=workers_max).contains(&workers) {
        return Json(err_response::<serde_json::Value>(format!(
            "Число воркеров должно быть от {workers_min} до {workers_max}"
        )));
    }
    // Правило 27:1 — только для пула; легаси- и автовк-клиенты его не знают.
    let capped = clamp_workers(workers, hashes);
    if format == ConfFormat::Pool && capped != workers {
        workers = capped;
    }
    if format != ConfFormat::Pool && (vk.is_empty() || !vk.split(',').all(|h| !h.trim().is_empty())) {
        return Json(err_response::<serde_json::Value>(
            "VK должен содержать хотя бы один непустой хеш",
        ));
    }
    if tun.is_empty() || !tun.chars().all(|c| c.is_ascii_alphanumeric() || c == '_') {
        return Json(err_response::<serde_json::Value>("Недопустимое имя TUN-интерфейса"));
    }
    // Валидация: пары ключ=значение шела не должны ломаться содержимым полей
    for (key, val) in [("PEER", &peer), ("PASSWORD", &password), ("VK", &vk), ("TUN", &tun)] {
        if val.contains('"') || val.contains('\'') || val.contains('\n') || val.contains('\\') {
            return Json(err_response::<serde_json::Value>(format!(
                "Поле {key} содержит недопустимые символы"
            )));
        }
    }

    let updates: Vec<(String, String)> = match format {
        ConfFormat::Legacy => vec![
            ("PEER".into(), peer),
            ("PASSWORD".into(), password),
            ("VK".into(), vk),
            ("TUN".into(), tun),
            ("N".into(), workers.to_string()),
        ],
        ConfFormat::AutoVk => vec![
            ("PEER".into(), peer),
            ("PASSWORD".into(), password),
            // В автовк-конфиге хеши живут в HASHES (установщик 0636 так писал)
            ("HASHES".into(), vk),
            ("WORKERS".into(), workers.to_string()),
            ("TUN_IFACE".into(), tun),
        ],
        ConfFormat::Pool => {
            let old_hashes: u32 = existing_pairs
                .iter()
                .find(|(k, _)| k == "HASHES")
                .and_then(|(_, v)| v.parse().ok())
                .unwrap_or(hashes);
            // Смена HASHES на живом пуле требует его сброса (установщик
            // предупреждает то же самое): старые звонки VK закроет сам VK.
            let mut pool_reset = false;
            if old_hashes != hashes && Path::new(CSQTT_POOL).exists() {
                match fs::remove_file(CSQTT_POOL) {
                    Ok(()) => pool_reset = true,
                    Err(e) => {
                        return Json(err_response::<serde_json::Value>(format!(
                            "Не удалось сбросить пул хешей перед сменой HASHES: {e}"
                        )))
                    }
                }
            }
            if pool_reset {
                log("INFO", format!("Пул хешей сброшен: HASHES {old_hashes} → {hashes}"));
            }
            vec![
                ("PEER".into(), peer),
                ("PASSWORD".into(), password),
                ("HASHES".into(), hashes.to_string()),
                ("WORKERS".into(), workers.to_string()),
                ("TUN_IFACE".into(), tun),
            ]
        }
    };

    let content = render_conf(&existing, &updates);
    if let Err(e) = fs::write(CSQTT_CONF, content) {
        return Json(err_response::<serde_json::Value>(format!(
            "Не удалось записать csqtt.conf: {e}"
        )));
    }
    let _ = fs::set_permissions(CSQTT_CONF, fs::Permissions::from_mode(0o600));

    let restarted = if req.restart && Path::new(CSQTT_INIT).exists() {
        log("INFO", "Перезапуск CSQTT после изменения конфигурации".into());
        Command::new(CSQTT_INIT)
            .arg("restart")
            .output()
            .await
            .is_ok()
    } else {
        false
    };

    log("INFO", "Конфигурация CSQTT обновлена".into());

    Json(ApiResponse {
        success: true,
        error: None,
        data: Some(json!({ "restarted": restarted, "workers": workers })),
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_legacy_conf() {
        let content = "PEER='94.242.58.236:46000'\nPASSWORD='C8gYBX2NCE9vXBbH'\nVK='h1,h2'\nTUN='csqtt0'\nN='108'\n";
        let conf = parse_conf(content);
        assert_eq!(conf.format, "legacy");
        assert!(conf.legacy);
        assert_eq!(conf.peer, "94.242.58.236:46000");
        assert_eq!(conf.vk, "h1,h2");
        assert_eq!(conf.workers, 108);
        assert_eq!(conf.hashes, 2);
        assert_eq!(conf.tun, "csqtt0");
        assert!(conf.link.contains("hashes=h1+h2"));
        assert!(conf.link.contains("host=94.242.58.236"));
    }

    #[test]
    fn parse_pool_conf_keeps_other_keys_in_get() {
        let content = "# CSQTT client config\n\
            PEER=\"1.2.3.4:46000\"\n\
            PASSWORD=\"secret\"\n\
            HASHES=\"4\"\n\
            WORKERS=\"108\"\n\
            DEVICE_ID=\"Keenetic-dc9c95f6\"\n\
            TUN_IFACE=\"csqtt0\"\n";
        let conf = parse_conf(content);
        assert_eq!(conf.format, "pool");
        assert!(!conf.legacy);
        assert_eq!(conf.hashes, 4);
        assert_eq!(conf.workers, 108);
        assert_eq!(conf.peer, "1.2.3.4:46000");
        assert!(conf.link.is_empty());
    }

    #[test]
    fn parse_autovk_conf_with_string_hashes() {
        // Конфиг установщика 0636: HASHES = строка-хеш, VK_MODE=auto_js
        let content = "# CSQTT client config\n\
            PEER=\"2.27.16.91:46000\"\n\
            PASSWORD=\"MzmkzpmrQXY8e3Yq\"\n\
            HASHES=\"XXnttg1FmLYxcVad_NZWt0dqmY0OZE91SnSXz8qpcwQ\"\n\
            VK_MODE=\"auto_js\"\n\
            WORKERS=\"54\"\n\
            DEVICE_ID=\"Keenetic-dc9c95f6\"\n\
            LISTEN=\"127.0.0.1:9000\"\n\
            FINGERPRINT=\"firefox\"\n\
            CLIENT_IDS=\"8202606,6287487\"\n\
            OBFS=\"video\"\n\
            TURN_TRANSPORT=\"udp\"\n\
            CAPTCHA_MODE=\"auto\"\n\
            TUN_IFACE=\"csqtt0\"\n\
            TUN_MTU=\"1300\"\n";
        let conf = parse_conf(content);
        assert_eq!(conf.format, "autovk");
        assert!(!conf.legacy);
        // Хеш читается из HASHES как строка
        assert_eq!(conf.vk, "XXnttg1FmLYxcVad_NZWt0dqmY0OZE91SnSXz8qpcwQ");
        assert_eq!(conf.workers, 54);
        assert_eq!(conf.hashes, 1);
        assert_eq!(conf.tun, "csqtt0");
        assert!(conf.link.contains("hashes=XXnttg1FmLYxcVad"));
        assert!(!conf.link.is_empty());
    }

    #[test]
    fn autovk_conf_without_vk_mode_detected_by_string_hashes() {
        // VK_MODE мёртвый — его может не быть; строка в HASHES выдаёт автовк
        let content = "PEER=\"1.1.1.1:46000\"\n\
            PASSWORD=\"p\"\n\
            HASHES=\"abc,def\"\n\
            WORKERS=\"54\"\n\
            TUN_IFACE=\"csqtt0\"\n";
        let conf = parse_conf(content);
        assert_eq!(conf.format, "autovk");
        assert_eq!(conf.vk, "abc,def");
        assert_eq!(conf.hashes, 2);
        assert_eq!(conf.workers, 54);
    }

    #[test]
    fn autovk_workers_capped_at_126() {
        let content = "PEER=\"1.1.1.1:1\"\nPASSWORD=\"p\"\nHASHES=\"abc\"\nVK_MODE=\"auto_js\"\nWORKERS=\"200\"\n";
        let conf = parse_conf(content);
        assert_eq!(conf.format, "autovk");
        assert_eq!(conf.workers, 126);
    }

    #[test]
    fn render_conf_replaces_form_keys_and_keeps_rest() {
        let existing = "# CSQTT client config\n\
            PEER=\"old:1\"\n\
            PASSWORD=\"old\"\n\
            HASHES=\"2\"\n\
            WORKERS=\"54\"\n\
            DEVICE_ID=\"dev-1\"\n\
            FINGERPRINT=\"firefox\"\n\
            TUN_IFACE=\"csqtt0\"\n";
        let updates = vec![
            ("PEER".to_string(), "new:2".to_string()),
            ("PASSWORD".to_string(), "newpass".to_string()),
            ("HASHES".to_string(), "4".to_string()),
            ("WORKERS".to_string(), "108".to_string()),
            ("TUN_IFACE".to_string(), "csqtt0".to_string()),
        ];
        let out = render_conf(existing, &updates);
        assert!(out.contains("# CSQTT client config"));
        assert!(out.contains("DEVICE_ID=\"dev-1\""));
        assert!(out.contains("FINGERPRINT=\"firefox\""));
        assert!(out.contains("PEER=\"new:2\""));
        assert!(out.contains("PASSWORD=\"newpass\""));
        assert!(out.contains("HASHES=\"4\""));
        assert!(!out.contains("PEER=\"old:1\""));
        let roundtrip = parse_conf(&out);
        assert_eq!(roundtrip.hashes, 4);
        assert_eq!(roundtrip.workers, 108);
    }

    #[test]
    fn render_autovk_conf_roundtrip_keeps_advanced_keys() {
        // Круговая запись автовк-конфига: VK_MODE/DEVICE_ID/FINGERPRINT и пр. живы
        let existing = "PEER=\"2.27.16.91:46000\"\n\
            PASSWORD=\"old\"\n\
            HASHES=\"XXnttg1FmLYxcVad_NZWt0dqmY0OZE91SnSXz8qpcwQ\"\n\
            VK_MODE=\"auto_js\"\n\
            WORKERS=\"54\"\n\
            DEVICE_ID=\"Keenetic-dc9c95f6\"\n\
            LISTEN=\"127.0.0.1:9000\"\n\
            FINGERPRINT=\"firefox\"\n\
            CLIENT_IDS=\"8202606,6287487\"\n\
            OBFS=\"video\"\n\
            TURN_TRANSPORT=\"udp\"\n\
            CAPTCHA_MODE=\"auto\"\n\
            TUN_IFACE=\"csqtt0\"\n\
            TUN_MTU=\"1300\"\n";
        let updates = vec![
            ("PEER".to_string(), "9.9.9.9:46000".to_string()),
            ("PASSWORD".to_string(), "newpass".to_string()),
            ("HASHES".to_string(), "XXnttg1FmLYxcVad_NZWt0dqmY0OZE91SnSXz8qpcwQ".to_string()),
            ("WORKERS".to_string(), "54".to_string()),
            ("TUN_IFACE".to_string(), "csqtt0".to_string()),
        ];
        let out = render_conf(existing, &updates);
        assert!(out.contains("VK_MODE=\"auto_js\""));
        assert!(out.contains("DEVICE_ID=\"Keenetic-dc9c95f6\""));
        assert!(out.contains("LISTEN=\"127.0.0.1:9000\""));
        assert!(out.contains("FINGERPRINT=\"firefox\""));
        assert!(out.contains("CLIENT_IDS=\"8202606,6287487\""));
        assert!(out.contains("OBFS=\"video\""));
        assert!(out.contains("TURN_TRANSPORT=\"udp\""));
        assert!(out.contains("CAPTCHA_MODE=\"auto\""));
        assert!(out.contains("TUN_MTU=\"1300\""));
        assert!(out.contains("PEER=\"9.9.9.9:46000\""));
        let roundtrip = parse_conf(&out);
        assert_eq!(roundtrip.format, "autovk");
        assert_eq!(roundtrip.vk, "XXnttg1FmLYxcVad_NZWt0dqmY0OZE91SnSXz8qpcwQ");
        assert_eq!(roundtrip.workers, 54);
    }

    #[test]
    fn render_legacy_conf_with_single_quotes_roundtrip() {
        let existing = "PEER='old'\nPASSWORD='x'\nVK='h1'\nTUN='csqtt0'\nN='54'\n";
        let updates = vec![
            ("PEER".to_string(), "9.9.9.9:46000".to_string()),
            ("PASSWORD".to_string(), "p2".to_string()),
            ("VK".to_string(), "h1,h2".to_string()),
            ("TUN".to_string(), "csqtt0".to_string()),
            ("N".to_string(), "54".to_string()),
        ];
        let out = render_conf(existing, &updates);
        assert!(out.contains("PEER=\"9.9.9.9:46000\""));
        let roundtrip = parse_conf(&out);
        assert_eq!(roundtrip.format, "legacy");
        assert_eq!(roundtrip.vk, "h1,h2");
        assert_eq!(roundtrip.workers, 54);
    }

    #[test]
    fn clamp_workers_follows_27_per_hash() {
        assert_eq!(clamp_workers(108, 4), 108);
        assert_eq!(clamp_workers(162, 4), 108);
        assert_eq!(clamp_workers(54, 2), 54);
        assert_eq!(clamp_workers(55, 2), 54);
        assert_eq!(clamp_workers(10, 1), 9);
        assert_eq!(clamp_workers(9, 1), 9);
    }

    #[test]
    fn build_link_encodes_hashes() {
        let link = build_link("94.242.58.236:46000", "C8gYBX2NCE9vXBbH", "abc,de/f");
        assert_eq!(
            link,
            "csqtt://connect?v=2&host=94.242.58.236&peer=46000&password=C8gYBX2NCE9vXBbH&hashes=abc+de%2Ff"
        );
    }

    #[test]
    fn detect_format_empty_hashes_is_pool() {
        // Слим-конфиг 0200 и пул 1341: HASHES=4 (число); VK_MODE у 1341 есть,
        // но число в HASHES выдаёт пул
        let pairs = parse_conf_lines(
            "PEER=\"1.1.1.1:1\"\nHASHES=\"4\"\nWORKERS=\"108\"\nVK_MODE=\"auto_js\"\n",
        );
        assert_eq!(detect_format(&pairs), ConfFormat::Pool);
        // Пустой HASHES без VK и VK_MODE — считаем пулом (неопределённый конфиг)
        let pairs = parse_conf_lines("PEER=\"1.1.1.1:1\"\nHASHES=\"\"\nWORKERS=\"108\"\n");
        assert_eq!(detect_format(&pairs), ConfFormat::Pool);
    }
}
