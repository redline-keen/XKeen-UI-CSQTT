import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Spinner } from '@/components/ui/spinner'
import { Textarea } from '@/components/ui/textarea'
import { IconAlertTriangle, IconLink, IconPlug } from '@tabler/icons-react'
import { useEffect, useState } from 'react'
import { apiCall } from '../../lib/api'
import { useModalContext } from '../../lib/store'

type CsqttConfig = {
  peer: string
  password: string
  vk: string
  /** legacy | pool | autovk */
  format: string
  legacy: boolean
  hashes: number
  workers: number
  tun: string
  running: boolean
  link: string
  pool_size: number
}

type FormState = {
  peer: string
  password: string
  vk: string
  tun: string
  n: string
  hashes: string
  workers: string
}

const EMPTY_FORM: FormState = { peer: '', password: '', vk: '', tun: 'csqtt0', n: '108', hashes: '4', workers: '108' }

const MAX_HASHES = 6
const WORKERS_PER_HASH = 27
const WORKERS_STEP = 9
const AUTOVK_MAX_WORKERS = 126

type ConfFormat = 'legacy' | 'pool' | 'autovk'

/** Кап воркеров по правилу пула-клиента 27:1 + выравнивание к шагу 9 (как бэкенд) */
function clampWorkers(workers: number, hashes: number): number {
  const cap = Math.max(1, Math.min(MAX_HASHES, hashes)) * WORKERS_PER_HASH
  let w = Math.max(WORKERS_STEP, Math.min(workers, cap))
  w = Math.floor(w / WORKERS_STEP) * WORKERS_STEP
  return Math.max(WORKERS_STEP, w)
}

/** Разбирает csqtt://connect?v=2&host=H&peer=P&password=X[&hashes=h1+h2] по правилам
 *  установщиков: %3A/%2F декодируются, хеши через '+' превращаются в список через запятую.
 *  Есть hashes= — хеши известны (легаси- и автовк-конфиги), нет — пул создаст клиент. */
function parseLink(link: string): { fields: Partial<FormState>; hashCount?: number; hasHashes: boolean } | null {
  const params = link.split('?')[1]
  if (!params) return null
  const get = (key: string) => {
    const m = params.match(new RegExp(`(?:^|&)${key}=([^&]*)`))
    return m ? m[1] : ''
  }
  const host = get('host')
  const peer = get('peer')
  const password = get('password')
  const hashes = get('hashes')
  if (!host || !peer || !password) return null
  if (!hashes) {
    return { fields: { peer: `${host}:${peer}`, password }, hasHashes: false }
  }
  const vk = hashes
    .split('+')
    .filter((h) => h.length > 0)
    .map((h) => h.replace(/%3A/g, ':').replace(/%3a/g, ':').replace(/%2F/g, '/').replace(/%2f/g, '/'))
    .join(',')
  if (!vk) return null
  return { fields: { peer: `${host}:${peer}`, password, vk }, hashCount: vk.split(',').length, hasHashes: true }
}

export function CsqttConfigModal() {
  const { modals, dispatch } = useModalContext()
  const open = modals.showCsqttConfigModal
  const close = () => dispatch({ type: 'SHOW_MODAL', modal: 'showCsqttConfigModal', show: false })

  const [config, setConfig] = useState<CsqttConfig | null>(null)
  const [form, setForm] = useState<FormState>(EMPTY_FORM)
  const [linkInput, setLinkInput] = useState('')
  const [restart, setRestart] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [linkError, setLinkError] = useState<string | null>(null)
  const [linkNote, setLinkNote] = useState<string | null>(null)

  const format: ConfFormat =
    config?.format === 'legacy' || config?.format === 'autovk' || config?.format === 'pool' ? config.format : 'pool'

  useEffect(() => {
    if (!open) return
    setError(null)
    setLinkError(null)
    setLinkNote(null)
    setLinkInput('')
    apiCall<CsqttConfig>('GET', 'csqtt/config')
      .then((c) => {
        setConfig(c)
        setForm(
          c.format === 'legacy'
            ? { ...EMPTY_FORM, peer: c.peer, password: c.password, vk: c.vk, tun: c.tun, n: String(c.workers) }
            : c.format === 'autovk'
              ? { ...EMPTY_FORM, peer: c.peer, password: c.password, vk: c.vk, tun: c.tun, workers: String(c.workers) }
              : { ...EMPTY_FORM, peer: c.peer, password: c.password, tun: c.tun, hashes: String(c.hashes), workers: String(c.workers) },
        )
      })
      .catch(() => setError('CSQTT не установлен или конфиг недоступен'))
  }, [open])

  const applyLink = () => {
    setLinkError(null)
    setLinkNote(null)
    const parsed = parseLink(linkInput.trim())
    if (!parsed) {
      setLinkError('Некорректная ссылка: нужны параметры host, peer и password')
      return
    }
    if (parsed.hasHashes && format === 'pool') {
      // Ссылка со старым списком хешей на пуле: хеши в пул не вставить, но их
      // число подставляем в HASHES — клиент создаст столько же звонков сам.
      const count = parsed.hashCount ?? 0
      setForm((f) => ({
        ...f,
        ...parsed.fields,
        vk: f.vk,
        hashes: String(Math.max(1, Math.min(MAX_HASHES, count))),
      }))
      setLinkNote(
        `Ссылка со списком хешей (${count} шт.). В схеме пула хеши берутся из vk_pool: HASHES установлен в ${Math.min(MAX_HASHES, count)}, пул клиент создаст сам по токену.`,
      )
      return
    }
    setForm((f) => ({ ...f, ...parsed.fields }))
    if (!parsed.hasHashes) {
      setLinkNote(
        format === 'pool'
          ? 'Ссылка без хешей: пул создаст клиент по VK-токену.'
          : 'Ссылка без хешей: звонок VK создаст клиент по токену.',
      )
    }
  }

  const set = (key: keyof FormState) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }))

  const save = async () => {
    setError(null)
    if (!form.peer.includes(':')) {
      setError('PEER должен быть в формате host:port')
      return
    }
    const workersMax = format === 'autovk' ? AUTOVK_MAX_WORKERS : 162
    let body: Record<string, unknown>
    if (format === 'legacy') {
      const n = Number(form.n)
      if (!Number.isInteger(n) || n < 9 || n > 162) {
        setError('Число потоков должно быть целым от 9 до 162')
        return
      }
      body = { peer: form.peer, password: form.password, vk: form.vk, tun: form.tun || 'csqtt0', workers: n }
    } else if (format === 'autovk') {
      const workers = Number(form.workers)
      if (!Number.isInteger(workers) || workers < 9 || workers > workersMax) {
        setError(`Число воркеров должно быть целым от 9 до ${workersMax}`)
        return
      }
      if (!form.vk.trim()) {
        setError('VK должен содержать хотя бы один непустой хеш')
        return
      }
      body = { peer: form.peer, password: form.password, vk: form.vk, tun: form.tun || 'csqtt0', workers }
    } else {
      const hashes = Number(form.hashes)
      const workers = clampWorkers(Number(form.workers), hashes)
      if (!Number.isInteger(hashes) || hashes < 1 || hashes > MAX_HASHES) {
        setError(`Число хешей должно быть целым от 1 до ${MAX_HASHES}`)
        return
      }
      if (!Number.isInteger(workers) || workers < 9 || workers > 162) {
        setError('Число воркеров должно быть целым от 9 до 162')
        return
      }
      body = { peer: form.peer, password: form.password, tun: form.tun || 'csqtt0', hashes, workers }
    }
    setSaving(true)
    try {
      await apiCall('POST', 'csqtt/config', { ...body, restart: restart && (config?.running ?? true) })
      close()
    } catch (e: any) {
      setError(e?.error || String(e))
    } finally {
      setSaving(false)
    }
  }

  const hashCount = form.vk ? form.vk.split(',').filter((h) => h.trim()).length : 0
  const workersCap = clampWorkers(Number(form.workers) || 9, Number(form.hashes) || 1)

  const formatDescription =
    format === 'legacy'
      ? 'Установлена старая линейка клиента (VK-хеши в конфиге). Замена ссылки целиком или правка полей.'
      : format === 'autovk'
        ? 'Авторежим ВК: хеш звонка в HASHES создаёт клиент по VK-токену. Замена ссылки целиком или правка полей.'
        : 'Конфигурация подключения. Хеши VK живут в пуле (vk_pool) — их создаёт и ротирует клиент по VK-токену.'

  return (
    <Dialog open={open} onOpenChange={(o) => !o && close()}>
      <DialogContent className="flex max-h-[90dvh]! max-w-2xl! flex-col overflow-hidden p-4 sm:p-5">
        <DialogHeader className="shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <IconPlug size={24} className="text-chart-2" /> Конфигурация CSQTT
          </DialogTitle>
          <DialogDescription>{formatDescription}</DialogDescription>
        </DialogHeader>

        <div className="min-h-0 flex-1 space-y-4 overflow-y-auto pr-1">
          {error && (
            <div className="flex items-center gap-2 rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-400">
              <IconAlertTriangle size={16} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}

        {config === null ? (
          <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
            <Spinner className="size-4" /> Загрузка конфигурации...
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5">
                <IconLink size={14} /> Новая ссылка csqtt:// (необязательно)
              </Label>
              <div className="flex gap-2">
                <Input
                  placeholder="csqtt://connect?v=2&host=…&peer=…&password=…[&hashes=…]"
                  value={linkInput}
                  onChange={(e) => setLinkInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && applyLink()}
                />
                <Button variant="outline" size="sm" className="shrink-0" onClick={applyLink}>
                  Применить
                </Button>
              </div>
              {linkError && <p className="text-xs text-red-400">{linkError}</p>}
              {linkNote && (
                <p className="flex items-start gap-1.5 rounded-md border border-chart-2/30 bg-chart-2/10 px-2.5 py-1.5 text-xs text-foreground">
                  <IconAlertTriangle size={14} className="mt-0.5 shrink-0 text-chart-2" />
                  <span>{linkNote}</span>
                </p>
              )}
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="csqtt-peer">PEER (host:port)</Label>
                <Input id="csqtt-peer" value={form.peer} onChange={set('peer')} placeholder="94.242.58.236:46000" />
              </div>
              {format === 'legacy' ? (
                <div className="space-y-1.5">
                  <Label htmlFor="csqtt-n">Потоки N (9–162)</Label>
                  <Input id="csqtt-n" type="number" min={9} max={162} value={form.n} onChange={set('n')} />
                </div>
              ) : format === 'autovk' ? (
                <div className="space-y-1.5">
                  <Label htmlFor="csqtt-workers">Воркеры (9–126)</Label>
                  <Input id="csqtt-workers" type="number" min={9} max={126} step={9} value={form.workers} onChange={set('workers')} />
                  <p className="text-xs text-muted-foreground">Авторежим: правило 27:1 не применяется</p>
                </div>
              ) : (
                <div className="space-y-1.5">
                  <Label htmlFor="csqtt-hashes">Хешей в пуле (1–6)</Label>
                  <Input id="csqtt-hashes" type="number" min={1} max={6} value={form.hashes} onChange={set('hashes')} />
                </div>
              )}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="csqtt-password">PASSWORD</Label>
              <Input id="csqtt-password" value={form.password} onChange={set('password')} />
            </div>

            {format === 'legacy' || format === 'autovk' ? (
              <div className="space-y-1.5">
                <Label htmlFor="csqtt-vk">
                  {format === 'autovk' ? `VK-хеш звонка (${hashCount})` : `VK-хеши (${hashCount})`}
                </Label>
                <Textarea
                  id="csqtt-vk"
                  value={form.vk}
                  onChange={set('vk')}
                  className="min-h-20 font-mono text-xs"
                  placeholder={format === 'autovk' ? 'хеш звонка (создаётся по токену)' : 'хеш1,хеш2,…'}
                />
                {format === 'autovk' && (
                  <p className="text-xs text-muted-foreground">
                    Хеш из HASHES конфига; записывается обратно в HASHES. Клиент обновит его сам после пересоздания звонка.
                  </p>
                )}
              </div>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="csqtt-workers">Воркеры (9–162)</Label>
                  <Input id="csqtt-workers" type="number" min={9} max={162} step={9} value={form.workers} onChange={set('workers')} />
                  <p className="text-xs text-muted-foreground">
                    Максимум {workersCap} для {form.hashes || 1} хешей (правило 27:1, выравнивание к 9)
                  </p>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="csqtt-pool">Пул хешей (vk_pool)</Label>
                  <div className="rounded-md border px-3 py-2 text-sm">
                    {config.pool_size} записей — управляет клиент по VK-токену
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Смена числа хешей пересоздаёт пул (старые звонки VK закроет сам VK)
                  </p>
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="csqtt-tun">TUN-интерфейс</Label>
              <Input id="csqtt-tun" value={form.tun} onChange={set('tun')} placeholder="csqtt0" />
            </div>
          </div>
        )}
        </div>

        <DialogFooter className="flex-col! shrink-0 gap-2 border-t pt-3 sm:flex-row sm:justify-between">
          <label className="flex cursor-pointer items-center gap-2 text-sm text-muted-foreground">
            <Checkbox checked={restart} onCheckedChange={(v) => setRestart(!!v)} />
            Перезапустить CSQTT после сохранения
            {config?.running === false && <span className="text-xs">(сейчас не запущен)</span>}
          </label>
          <div className="flex gap-2">
            <Button variant="outline" onClick={close}>
              Отмена
            </Button>
            <Button onClick={save} disabled={saving || config === null}>
              {saving && <Spinner className="mr-1 size-3.5" />} Сохранить
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
