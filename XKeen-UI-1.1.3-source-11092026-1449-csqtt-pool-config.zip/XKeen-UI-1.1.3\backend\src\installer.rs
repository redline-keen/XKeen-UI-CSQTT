use crate::logger::log;
use crate::types::*;
use axum::extract::ws::{Message, WebSocket, WebSocketUpgrade};
use axum::extract::State;
use axum::response::{IntoResponse, Json};
use futures_util::sink::SinkExt;
use futures_util::stream::{SplitSink, StreamExt};
use nix::libc::{
    TIOCSCTTY, TIOCSWINSZ, WEXITSTATUS, WIFEXITED, WNOHANG, _exit, c_int, close, dup2, ioctl,
    waitpid, write as libc_write,
};
use nix::pty::{OpenptyResult, Winsize, openpty};
use nix::sys::signal::{Signal, kill};
use nix::unistd::{ForkResult, Pid, close as nix_close, dup, execve, fork, getpid, setsid, tcsetpgrp};
use std::ffi::CString;
use std::io::Read;
use std::os::fd::{AsRawFd, OwnedFd};
use std::os::unix::fs::PermissionsExt;
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Mutex, OnceLock};
use std::time::Duration;
use tokio::sync::broadcast;

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum InstallKind {
    Xkeen,
    Csqtt,
    Qwdtt,
}

impl InstallKind {
    fn from_str(s: &str) -> Option<Self> {
        match s {
            "xkeen" => Some(InstallKind::Xkeen),
            "csqtt" => Some(InstallKind::Csqtt),
            "qwdtt" => Some(InstallKind::Qwdtt),
            _ => None,
        }
    }

    fn title(self) -> &'static str {
        match self {
            InstallKind::Xkeen => "XKeen",
            InstallKind::Csqtt => "CSQTT",
            InstallKind::Qwdtt => "qWDTT",
        }
    }

    fn script_urls(self) -> Vec<&'static str> {
        match self {
            InstallKind::Xkeen => vec![
                "https://raw.githubusercontent.com/jameszeroX/XKeen/main/install.sh",
                "https://cdn.jsdelivr.net/gh/jameszeroX/XKeen@main/install.sh",
            ],
            InstallKind::Csqtt => vec![
                "https://raw.githubusercontent.com/redline-keen/csqtt-xkeen/main/csqtt-xkeen-only-client-install.sh",
                "https://cdn.jsdelivr.net/gh/redline-keen/csqtt-xkeen@main/csqtt-xkeen-only-client-install.sh",
            ],
            InstallKind::Qwdtt => vec![
                "https://raw.githubusercontent.com/redline-keen/wdtt-xkeen/refs/heads/main/install-wdtt.sh",
                "https://cdn.jsdelivr.net/gh/redline-keen/wdtt-xkeen@main/install-wdtt.sh",
            ],
        }
    }

    fn script_path(self) -> &'static str {
        match self {
            InstallKind::Xkeen => "/opt/tmp/xkeen-install.sh",
            InstallKind::Csqtt => "/opt/tmp/csqtt-install.sh",
            InstallKind::Qwdtt => "/opt/tmp/install-wdtt.sh",
        }
    }

    /// Команда удаления: сначала штатный деинсталлятор установщика,
    /// при его отсутствии — ручная зачистка всех созданных им путей
    /// (init-скрипт, cron-watchdog, бинарник, конфиги, tun-интерфейс)
    fn uninstall_argv(self) -> Vec<String> {
        let manual = match self {
            InstallKind::Csqtt => "u=/opt/etc/csqtt/uninstall.sh; [ -x \"$u\" ] && exec sh \"$u\"; /opt/etc/init.d/S99csqtt stop 2>/dev/null; killall -9 csqtt-client 2>/dev/null; ip link del csqtt0 2>/dev/null; crontab_root=/opt/var/spool/cron/crontabs/root; [ -f \"$crontab_root\" ] && sed -i '/csqtt/d' \"$crontab_root\"; [ -x /opt/etc/init.d/S10cron ] && /opt/etc/init.d/S10cron restart 2>/dev/null; rm -f /opt/etc/init.d/S99csqtt /opt/var/run/csqtt-client.pid /opt/bin/csqtt-uninstall; rm -rf /opt/etc/csqtt",
            InstallKind::Qwdtt => "u=/opt/usr/bin/wdtt-uninstall; [ -x \"$u\" ] && exec sh \"$u\"; /opt/etc/init.d/S99wdtt-client stop 2>/dev/null; killall -9 wdtt-client 2>/dev/null; ip link del wdtt0 2>/dev/null; crontab_root=/opt/var/spool/cron/crontabs/root; [ -f \"$crontab_root\" ] && sed -i '/wdtt/d' \"$crontab_root\"; [ -x /opt/etc/init.d/S10cron ] && /opt/etc/init.d/S10cron restart 2>/dev/null; rm -f /opt/etc/init.d/S99wdtt-client /opt/var/run/wdtt-client.pid /opt/usr/bin/wdtt-uninstall /opt/var/log/watchdog.log; rm -rf /opt/etc/wdtt",
            InstallKind::Xkeen => "",
        };
        vec!["/bin/sh".to_string(), "-c".to_string(), manual.to_string()]
    }

    /// Команда запуска в PTY: скрипт csqtt читает ссылку из /dev/tty,
    /// поэтому он должен выполняться на управляющем терминале (наш PTY им и является)
    fn argv(self) -> Vec<String> {
        let script_path = self.script_path().to_string();
        match self {
            InstallKind::Xkeen => vec![
                "/bin/sh".to_string(),
                "-c".to_string(),
                format!("cd /tmp && opkg install curl tar; sh {script_path}"),
            ],
            InstallKind::Csqtt => vec![
                "/bin/sh".to_string(),
                "-c".to_string(),
                format!("opkg update; opkg install curl; curl -k -fsSL -o {script_path} https://raw.githubusercontent.com/redline-keen/csqtt-xkeen/main/csqtt-xkeen-only-client-install.sh && sh {script_path} < /dev/tty"),
            ],
            // Установщик qWDTT качает бинарник wget-ом и читает ответы из /dev/tty
            InstallKind::Qwdtt => vec![
                "/bin/sh".to_string(),
                "-c".to_string(),
                format!("opkg update && opkg install wget-ssl ca-bundle; wget --no-check-certificate -O {script_path} https://raw.githubusercontent.com/redline-keen/wdtt-xkeen/refs/heads/main/install-wdtt.sh && sh {script_path}"),
            ],
        }
    }

    fn installed(self) -> bool {
        match self {
            InstallKind::Xkeen => {
                Path::new(S99XKEEN).exists() || Path::new(S24XRAY).exists() || Path::new("/opt/sbin/.xkeen").exists()
            }
            InstallKind::Csqtt => {
                Path::new("/opt/etc/init.d/S99csqtt").exists()
                    || Path::new("/opt/etc/csqtt/csqtt-client").exists()
                    || Path::new("/opt/bin/csqtt-uninstall").exists()
            }
            InstallKind::Qwdtt => {
                Path::new("/opt/etc/init.d/S99wdtt-client").exists()
                    || Path::new("/opt/usr/bin/wdtt-client").exists()
            }
        }
    }
}

/// Скроллбек для клиентов, переподключившихся к идущей установке
const SCROLLBACK_CAP: usize = 256 * 1024;

/// Параллельный запуск установщиков на роутере может ломать opkg
/// и конфигурацию, поэтому активная установка возможна только одна.
static INSTALL_RUNNING: AtomicBool = AtomicBool::new(false);

#[derive(Clone)]
enum SessionEvent {
    Chunk(Vec<u8>),
    Exit(i32),
}

struct InstallSession {
    kind: InstallKind,
    scrollback: Vec<u8>,
    tx: broadcast::Sender<SessionEvent>,
    master_fd: i32,
    write_fd: i32,
    child_pid: Pid,
    exit_code: Option<i32>,
}

impl Drop for InstallSession {
    fn drop(&mut self) {
        // write_fd принадлежит сессии целиком и закрывается только здесь;
        // master живёт в OwnedFd reader-потока и закрывается при его завершении
        unsafe {
            close(self.write_fd);
        }
    }
}

static SESSION: OnceLock<Mutex<Option<InstallSession>>> = OnceLock::new();

fn session_slot() -> &'static Mutex<Option<InstallSession>> {
    SESSION.get_or_init(|| Mutex::new(None))
}

fn session_running() -> (bool, Option<i32>) {
    match session_slot().lock().unwrap().as_ref() {
        Some(s) => (s.exit_code.is_none(), s.exit_code),
        None => (false, None),
    }
}

pub fn xkeen_installed() -> bool {
    InstallKind::Xkeen.installed()
}

pub fn csqtt_installed() -> bool {
    InstallKind::Csqtt.installed()
}

pub fn qwdtt_installed() -> bool {
    InstallKind::Qwdtt.installed()
}

/// Статус обеих установок; running без kind относится к текущей активной сессии
pub async fn get_install_status(State(_state): State<AppState>) -> impl IntoResponse {
    let (running, code, kind) = {
        let guard = session_slot().lock().unwrap();
        match guard.as_ref() {
            Some(s) => (s.exit_code.is_none(), s.exit_code, Some(s.kind)),
            None => (false, None, None),
        }
    };
    let kind_str = kind.map(|k| match k {
        InstallKind::Xkeen => "xkeen",
        InstallKind::Csqtt => "csqtt",
        InstallKind::Qwdtt => "qwdtt",
    });
    Json(serde_json::json!({
        "success": true,
        "installed": xkeen_installed(),
        "csqttInstalled": csqtt_installed(),
        "qwdttInstalled": qwdtt_installed(),
        "running": running,
        "kind": kind_str,
        "code": code,
    }))
}

pub async fn install_ws(ws: WebSocketUpgrade, State(state): State<AppState>) -> impl IntoResponse {
    ws.on_upgrade(move |socket| handle_install_socket(socket, state))
}

async fn fetch_install_script(state: &AppState, kind: InstallKind) -> Result<Vec<u8>, String> {
    let proxies = state.settings.read().unwrap().updater.github_proxy.clone();
    // Прямая ссылка → прокси из настроек → зеркало jsDelivr
    let mut urls: Vec<String> = vec![kind.script_urls()[0].to_string()];
    urls.extend(
        proxies
            .iter()
            .filter(|p| !p.trim().is_empty())
            .map(|p| format!("{}/{}", p.trim_end_matches('/'), kind.script_urls()[0])),
    );
    urls.push(kind.script_urls()[1].to_string());

    let mut last_err = String::from("нет ответа");
    for u in urls {
        match state
            .http_client
            .get(&u)
            .timeout(Duration::from_secs(30))
            .send()
            .await
        {
            Ok(r) if r.status().is_success() => match r.bytes().await {
                Ok(b) if !b.is_empty() => return Ok(b.to_vec()),
                Ok(_) => last_err = "пустой ответ".into(),
                Err(e) => last_err = e.to_string(),
            },
            Ok(r) => last_err = format!("HTTP {}", r.status()),
            Err(e) => last_err = e.to_string(),
        }
    }
    Err(format!("Не удалось загрузить установщик {} ({})", kind.title(), last_err))
}

/// Запускает команду в новом псевдотерминале.
/// Возвращает (master: OwnedFd, write_fd для ввода, pid дочернего процесса).
fn spawn_pty(argv: &[String]) -> Result<(OwnedFd, i32, Pid), String> {
    if argv.is_empty() {
        return Err("Пустая команда".into());
    }

    let OpenptyResult { master, slave } = openpty(
        &Winsize { ws_row: 30, ws_col: 100, ws_xpixel: 0, ws_ypixel: 0 },
        None,
    )
    .map_err(|e| format!("openpty: {}", e))?;

    // dup() возвращает OwnedFd без FD_CLOEXEC: забираем raw-fd во владение,
    // иначе временное значение дропнется и закроет дескриптор сразу после выражения
    let write_dup = dup(&master).map_err(|e| format!("dup: {}", e))?;
    let write_fd = write_dup.as_raw_fd();
    std::mem::forget(write_dup); // закрывается в Drop InstallSession

    // FD_CLOEXEC на всех дескрипторах PTY: после execve установщик не должен
    // наследовать лишние копии master/slave — иначе внучные процессы будут
    // держать PTY открытым и reader-поток не получит EOF после завершения
    for fd in [master.as_raw_fd(), slave.as_raw_fd(), write_fd] {
        unsafe {
            nix::libc::fcntl(fd, nix::libc::F_SETFD, nix::libc::FD_CLOEXEC);
        }
    }

    // Все аллокации — строго до fork(): в child допустимы только async-signal-safe вызовы
    let argv_c: Vec<CString> = argv
        .iter()
        .map(|s| CString::new(s.as_str()).unwrap_or_else(|_| CString::new("?").unwrap()))
        .collect();
    let env_c = vec![
        CString::new("TERM=xterm-256color").unwrap(),
        CString::new("PATH=/opt/sbin:/opt/bin:/opt/usr/sbin:/opt/usr/bin:/usr/sbin:/usr/bin:/sbin:/bin").unwrap(),
        CString::new("HOME=/root").unwrap(),
        CString::new("LANG=C.UTF-8").unwrap(),
        CString::new("LC_ALL=C.UTF-8").unwrap(),
    ];

    match unsafe { fork() } {
        Ok(ForkResult::Parent { child }) => {
            drop(slave);
            Ok((master, write_fd, child))
        }
        Ok(ForkResult::Child) => unsafe {
            let slave_fd = slave.as_raw_fd();
            let _ = setsid();
            // PTY становится управляющим терминалом сессии: без этого
            // /dev/tty недоступен и interactive-скрипты с "read ... < /dev/tty" падают
            ioctl(slave_fd, TIOCSCTTY, 0);
            let _ = tcsetpgrp(&slave, getpid());
            dup2(slave_fd, 0);
            dup2(slave_fd, 1);
            dup2(slave_fd, 2);
            let _ = execve(&argv_c[0], &argv_c, &env_c);
            _exit(127);
        },
        Err(e) => {
            drop(master);
            drop(slave);
            let _ = nix_close(write_fd);
            Err(format!("fork: {}", e))
        }
    }
}

fn pty_write_input(fd: i32, bytes: &[u8]) {
    let mut off = 0;
    while off < bytes.len() {
        let n = unsafe { libc_write(fd, bytes[off..].as_ptr().cast(), bytes.len() - off) };
        if n <= 0 {
            break;
        }
        off += n as usize;
    }
}

fn pty_resize(master_fd: i32, pid: Pid, rows: u16, cols: u16) {
    let ws = Winsize { ws_row: rows, ws_col: cols, ws_xpixel: 0, ws_ypixel: 0 };
    unsafe {
        // Константа типизирована libc под целевую платформу (c_ulong для gnu, c_int для musl)
        ioctl(master_fd, TIOCSWINSZ, &ws as *const Winsize);
    }
    let _ = kill(Pid::from_raw(-pid.as_raw()), Signal::SIGWINCH);
}

/// Запускает команду в PTY и регистрирует сессию (reader+waiter+scrollback).
/// Вызывается только при захваченном слоте INSTALL_RUNNING.
/// `label` — заголовок для лога (установка/удаление чего).
async fn start_pty_session(argv: &[String], kind: InstallKind, label: &str) -> Result<(), String> {
    let (master, write_fd, child_pid) = spawn_pty(argv)?;
    let master_fd = master.as_raw_fd();

    let (tx, _) = broadcast::channel::<SessionEvent>(512);

    // reader: вывод PTY → скроллбек + broadcast; владелец master-fd
    let tx_reader = tx.clone();
    std::thread::spawn(move || {
        let mut file = std::fs::File::from(master);
        let mut buf = [0u8; 4096];
        loop {
            match file.read(&mut buf) {
                Ok(0) => break,
                Ok(n) => {
                    let chunk = buf[..n].to_vec();
                    {
                        let mut guard = session_slot().lock().unwrap();
                        if let Some(s) = guard.as_mut() {
                            s.scrollback.extend_from_slice(&chunk);
                            if s.scrollback.len() > SCROLLBACK_CAP {
                                let excess = s.scrollback.len() - SCROLLBACK_CAP;
                                s.scrollback.drain(..excess);
                            }
                        }
                    }
                    let _ = tx_reader.send(SessionEvent::Chunk(chunk));
                }
                Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(_) => break, // EIO — процесс завершился
            }
        }
    });

    // waiter: waitpid → код завершения → освобождение слота установки
    let tx_waiter = tx.clone();
    let title = label.to_string();
    let pid_raw = child_pid.as_raw() as c_int;
    std::thread::spawn(move || {
        let mut status: c_int = 0;
        let mut code: i32 = -1;
        loop {
            let r = unsafe { waitpid(pid_raw, &mut status, WNOHANG) };
            if r == pid_raw {
                if WIFEXITED(status) {
                    code = WEXITSTATUS(status);
                }
                break;
            }
            if r == -1 {
                break;
            }
            std::thread::sleep(Duration::from_millis(150));
        }

        {
            let mut guard = session_slot().lock().unwrap();
            if let Some(s) = guard.as_mut() {
                s.exit_code = Some(code);
            }
        }
        let _ = tx_waiter.send(SessionEvent::Exit(code));
        INSTALL_RUNNING.store(false, Ordering::SeqCst);

        if code == 0 {
            log("INFO", format!("{} успешно завершена", title));
        } else {
            log("ERROR", format!("{} завершена с кодом {}", title, code));
        }
    });

    // Заменяем прошлую (завершённую) сессию; установка новых при живой —
    // исключена слотом INSTALL_RUNNING
    *session_slot().lock().unwrap() = Some(InstallSession {
        kind,
        scrollback: Vec::new(),
        tx,
        master_fd,
        write_fd,
        child_pid,
        exit_code: None,
    });
    Ok(())
}

/// Скачивает установщик и запускает его в PTY.
/// Сессия живёт до завершения процесса — даже если все клиенты отключились.
async fn start_install_session(state: &AppState, kind: InstallKind) -> Result<(), String> {
    if kind.installed() {
        log("WARN", format!("Запуск установки {} поверх существующей установки", kind.title()));
    }

    let script = fetch_install_script(state, kind).await?;
    let script_path = kind.script_path();
    if let Some(dir) = Path::new(script_path).parent() {
        let _ = tokio::fs::create_dir_all(dir).await;
    }
    tokio::fs::write(script_path, &script)
        .await
        .map_err(|e| format!("Не удалось записать {}: {}", script_path, e))?;
    tokio::fs::set_permissions(script_path, std::fs::Permissions::from_mode(0o755))
        .await
        .map_err(|e| format!("chmod {}: {}", script_path, e))?;

    log("INFO", format!("Запуск установки {} через веб-терминал", kind.title()));

    // curl (и tar для XKeen) нужны установщику; сбой opkg не блокирует запуск скрипта
    let argv = kind.argv();
    start_pty_session(&argv, kind, &format!("Установка {}", kind.title())).await
}

/// Запускает удаление в PTY — без скачивания, деинсталлятор уже на роутере.
async fn start_uninstall_session(kind: InstallKind) -> Result<(), String> {
    log("INFO", format!("Запуск удаления {} через веб-терминал", kind.title()));
    let argv = kind.uninstall_argv();
    start_pty_session(&argv, kind, &format!("Удаление {}", kind.title())).await
}

type WsTx = SplitSink<WebSocket, Message>;

/// Подключается к активной сессии: подписывается на события и ретранслирует скроллбек.
/// Возвращает None, если живой сессии нет.
async fn attach_live_session(ws_tx: &mut WsTx) -> Option<broadcast::Receiver<SessionEvent>> {
    let (rx, scrollback) = {
        let guard = session_slot().lock().unwrap();
        let session = guard.as_ref()?;
        if session.exit_code.is_some() {
            return None;
        }
        (session.tx.subscribe(), session.scrollback.clone())
    };
    if !scrollback.is_empty() {
        let _ = ws_tx.send(Message::Binary(scrollback.into())).await;
    }
    Some(rx)
}

async fn send_json(ws_tx: &mut WsTx, value: serde_json::Value) {
    let _ = ws_tx.send(Message::Text(value.to_string().into())).await;
}

async fn handle_install_socket(socket: WebSocket, state: AppState) {
    let (mut ws_tx, mut ws_rx) = socket.split();

    // Если установка уже идёт — сразу подключаемся к её терминалу
    let mut rx: Option<broadcast::Receiver<SessionEvent>> = attach_live_session(&mut ws_tx).await;

    {
        let (running, code) = session_running();
        let kind = session_slot().lock().unwrap().as_ref().map(|s| s.kind);
        let kind_str = kind.map(|k| match k {
            InstallKind::Xkeen => "xkeen",
            InstallKind::Csqtt => "csqtt",
            InstallKind::Qwdtt => "qwdtt",
        });
        send_json(
            &mut ws_tx,
            serde_json::json!({"type": "status", "installed": xkeen_installed(), "csqttInstalled": csqtt_installed(), "qwdttInstalled": qwdtt_installed(), "running": running, "kind": kind_str, "code": code}),
        )
        .await;
    }

    let mut ws_open = true;

    loop {
        tokio::select! {
            biased;
            event = async {
                match rx.as_mut() {
                    Some(r) => r.recv().await,
                    None => std::future::pending::<Result<SessionEvent, tokio::sync::broadcast::error::RecvError>>().await,
                }
            } => {
                match event {
                    Ok(SessionEvent::Chunk(chunk)) => {
                        if ws_open && ws_tx.send(Message::Binary(chunk.into())).await.is_err() {
                            ws_open = false;
                        }
                    }
                    Ok(SessionEvent::Exit(code)) => {
                        // Добираем хвост вывода: reader-поток может отставать от waitpid
                        let deadline = tokio::time::Instant::now() + Duration::from_millis(700);
                        if ws_open {
                            'drain: loop {
                                let Some(r) = rx.as_mut() else { break 'drain };
                                match tokio::time::timeout_at(deadline, r.recv()).await {
                                    Ok(Ok(SessionEvent::Chunk(c))) => {
                                        let _ = ws_tx.send(Message::Binary(c.into())).await;
                                    }
                                    _ => break 'drain,
                                }
                            }
                        }
                        if ws_open {
                            send_json(&mut ws_tx, serde_json::json!({"type": "exit", "code": code})).await;
                        }
                        // Соединение не закрываем: клиент может запросить повторный запуск
                        rx = None;
                        if !ws_open {
                            break;
                        }
                    }
                    // Отстали от канала — восстанавливаемся из скроллбека
                    Err(tokio::sync::broadcast::error::RecvError::Lagged(_)) => {
                        if ws_open {
                            let scrollback = session_slot().lock().unwrap().as_ref().map(|s| s.scrollback.clone()).unwrap_or_default();
                            send_json(&mut ws_tx, serde_json::json!({"type": "clear"})).await;
                            let _ = ws_tx.send(Message::Binary(scrollback.into())).await;
                        }
                    }
                    Err(tokio::sync::broadcast::error::RecvError::Closed) => break,
                }
            }
            maybe_msg = ws_rx.next(), if ws_open => {
                match maybe_msg {
                    Some(Ok(Message::Binary(data))) => {
                        let bytes: Vec<u8> = data.into();
                        let (fd, active) = {
                            let guard = session_slot().lock().unwrap();
                            guard.as_ref().map_or((0, false), |s| (s.write_fd, s.exit_code.is_none()))
                        };
                        if active {
                            let _ = tokio::task::spawn_blocking(move || pty_write_input(fd, &bytes)).await;
                        }
                    }
                    Some(Ok(Message::Text(txt))) => {
                        let v: serde_json::Value = serde_json::from_str(txt.as_str()).unwrap_or_default();
                        match v["type"].as_str() {
                            Some("start") if rx.is_none() => {
                                let kind = InstallKind::from_str(v["kind"].as_str().unwrap_or("xkeen")).unwrap_or(InstallKind::Xkeen);
                                let uninstall = v["action"].as_str() == Some("uninstall");
                                if INSTALL_RUNNING.compare_exchange(false, true, Ordering::SeqCst, Ordering::SeqCst).is_ok() {
                                    let _ = ws_tx
                                        .send(Message::Binary(
                                            "\u{1b}[2mПодготовка установщика, подождите...\u{1b}[0m\r\n".as_bytes().to_vec().into(),
                                        ))
                                        .await;
                                    let result = if uninstall {
                                        if kind == InstallKind::Xkeen {
                                            Err("Удаление XKeen из панели не поддерживается".to_string())
                                        } else if !kind.installed() {
                                            Err(format!("{} не установлен — удалять нечего", kind.title()))
                                        } else {
                                            start_uninstall_session(kind).await
                                        }
                                    } else {
                                        start_install_session(&state, kind).await
                                    };
                                    match result {
                                        Ok(()) => {
                                            rx = attach_live_session(&mut ws_tx).await;
                                        }
                                        Err(e) => {
                                            INSTALL_RUNNING.store(false, Ordering::SeqCst);
                                            log("ERROR", format!("Установка {}: {}", kind.title(), e));
                                            send_json(&mut ws_tx, serde_json::json!({"type": "error", "message": e})).await;
                                            send_json(&mut ws_tx, serde_json::json!({"type": "exit", "code": 1})).await;
                                        }
                                    }
                                } else {
                                    // Установку запускает другое соединение — подключаемся к нему
                                    let mut attached = None;
                                    for _ in 0..20 {
                                        tokio::time::sleep(Duration::from_millis(300)).await;
                                        if let Some(r) = attach_live_session(&mut ws_tx).await {
                                            attached = Some(r);
                                            break;
                                        }
                                        if !INSTALL_RUNNING.load(Ordering::SeqCst) {
                                            break;
                                        }
                                    }
                                    match attached {
                                        Some(r) => rx = Some(r),
                                        None => {
                                            send_json(&mut ws_tx, serde_json::json!({"type": "error", "message": "Установка уже выполняется в другой сессии"})).await;
                                        }
                                    }
                                }
                            }
                            Some("resize") => {
                                let (fd, pid, active) = {
                                    let guard = session_slot().lock().unwrap();
                                    guard.as_ref().map_or((0, Pid::from_raw(0), false), |s| {
                                        (s.master_fd, s.child_pid, s.exit_code.is_none())
                                    })
                                };
                                if active {
                                    let cols = v["cols"].as_u64().unwrap_or(100) as u16;
                                    let rows = v["rows"].as_u64().unwrap_or(30) as u16;
                                    let _ = tokio::task::spawn_blocking(move || pty_resize(fd, pid, rows, cols)).await;
                                }
                            }
                            Some("kill") => {
                                let (pid, active) = {
                                    let guard = session_slot().lock().unwrap();
                                    guard.as_ref().map_or((Pid::from_raw(0), false), |s| (s.child_pid, s.exit_code.is_none()))
                                };
                                if active {
                                    log("WARN", "Установка прервана пользователем".into());
                                    let _ = kill(Pid::from_raw(-pid.as_raw()), Signal::SIGTERM);
                                    let _ = kill(pid, Signal::SIGTERM);
                                }
                            }
                            _ => {}
                        }
                    }
                    Some(Ok(Message::Close(_))) | Some(Err(_)) | None => {
                        // Клиент ушёл. Если установка ещё идёт — сопровождаем её до
                        // завершения (без трансляции), иначе завершаем обработчик.
                        ws_open = false;
                        if rx.is_none() {
                            break;
                        }
                    }
                    _ => {}
                }
            }
        }
    }
}
