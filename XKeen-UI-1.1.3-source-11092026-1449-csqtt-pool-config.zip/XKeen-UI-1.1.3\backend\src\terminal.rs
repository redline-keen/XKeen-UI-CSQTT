use crate::logger::{log, ts};
use crate::types::*;
use axum::extract::State;
use axum::extract::ws::{Message, WebSocket, WebSocketUpgrade};
use axum::response::IntoResponse;
use futures_util::sink::SinkExt;
use futures_util::stream::{SplitSink, StreamExt};
use nix::libc::{
    TIOCSCTTY, TIOCSWINSZ, WEXITSTATUS, WIFEXITED, WNOHANG, c_int, close, dup2, ioctl,
    waitpid, write as libc_write,
};
use nix::pty::{OpenptyResult, Winsize, openpty};
use nix::sys::signal::{Signal, kill};
use nix::unistd::{ForkResult, Pid, close as nix_close, dup, execve, fork, getpid, setsid, tcsetpgrp};
use std::ffi::CString;
use std::io::Read;
use std::os::fd::{AsRawFd, OwnedFd};
use std::time::Duration;
use std::sync::Mutex;
use tokio::sync::broadcast;

/// Скроллбек для клиентов, переподключившихся к живому shell
const SCROLLBACK_CAP: usize = 256 * 1024;

/// Параллельные shell-сессии на роутере не нужны: одновременно живёт один терминал.
/// Слоты с завершённым кодом выхода перезаписываются при новом запуске.
static TERM_SLOT: Mutex<Option<TermSession>> = Mutex::new(None);

type Event = (EventKind, Vec<u8>);

#[derive(Clone, Copy, PartialEq, Eq)]
enum EventKind {
    Chunk,
    Exit,
}

struct TermSession {
    tx: broadcast::Sender<Event>,
    scrollback: Vec<u8>,
    master_fd: i32,
    write_fd: i32,
    child_pid: Pid,
    exit_code: Option<i32>,
}

impl Drop for TermSession {
    fn drop(&mut self) {
        // write_fd принадлежит сессии целиком и закрывается только здесь;
        // master живёт в OwnedFd reader-потока и закрывается при его завершении
        unsafe {
            close(self.write_fd);
        }
    }
}

/// Снимок слота: берётся коротко, без долгого удержания замка
struct TermSnapshot {
    tx: broadcast::Sender<Event>,
    scrollback: Vec<u8>,
    master_fd: i32,
    write_fd: i32,
    child_pid: Pid,
    exit_code: Option<i32>,
}

fn snapshot() -> Option<TermSnapshot> {
    let guard = TERM_SLOT.lock().unwrap();
    guard.as_ref().map(|s| TermSnapshot {
        tx: s.tx.clone(),
        scrollback: s.scrollback.clone(),
        master_fd: s.master_fd,
        write_fd: s.write_fd,
        child_pid: s.child_pid,
        exit_code: s.exit_code,
    })
}

/// Запускает login shell в новом псевдотерминале.
/// Возвращает (master: OwnedFd, write_fd для ввода, pid дочернего процесса).
fn spawn_shell(rows: u16, cols: u16) -> Result<(OwnedFd, i32, Pid), String> {
    let shell = ["/opt/bin/bash", "/bin/bash", "/opt/bin/ash", "/bin/ash", "/bin/sh"]
        .into_iter()
        .find(|p| std::path::Path::new(p).exists())
        .unwrap_or("/bin/sh");

    let OpenptyResult { master, slave } = openpty(
        &Winsize { ws_row: rows, ws_col: cols, ws_xpixel: 0, ws_ypixel: 0 },
        None,
    )
    .map_err(|e| format!("openpty: {}", e))?;

    // dup() возвращает OwnedFd без FD_CLOEXEC: забираем raw-fd во владение,
    // иначе временное значение дропнется и закроет дескриптор сразу после выражения
    let write_dup = dup(&master).map_err(|e| format!("dup: {}", e))?;
    let write_fd = write_dup.as_raw_fd();
    std::mem::forget(write_dup); // закрывается в Drop TermSession

    // FD_CLOEXEC на всех дескрипторах PTY: после execve shell не должен
    // наследовать лишние копии master/slave — иначе reader-поток не получит EOF
    for fd in [master.as_raw_fd(), slave.as_raw_fd(), write_fd] {
        unsafe {
            nix::libc::fcntl(fd, nix::libc::F_SETFD, nix::libc::FD_CLOEXEC);
        }
    }

    // Все аллокации — строго до fork(): в child допустимы только async-signal-safe вызовы
    let shell_c = CString::new(shell).unwrap();
    let arg0 = CString::new(format!("-{}", shell.rsplit('/').next().unwrap_or("sh"))).unwrap();
    let env_c = vec![
        CString::new("TERM=xterm-256color").unwrap(),
        CString::new("PATH=/opt/sbin:/opt/bin:/opt/usr/sbin:/opt/usr/bin:/usr/sbin:/usr/bin:/sbin:/bin").unwrap(),
        CString::new("HOME=/root").unwrap(),
        CString::new("PS1=\\w # ").unwrap(),
        CString::new("LANG=C.UTF-8").unwrap(),
        CString::new("LC_ALL=C.UTF-8").unwrap(),
    ];

    match unsafe { fork() } {
        Ok(ForkResult::Parent { child }) => {
            drop(slave);
            Ok((master, write_fd, child))
        }
        Ok(ForkResult::Child) => unsafe {
            let slave_fd = slave.as_raw_fd();
            let _ = setsid();
            // PTY становится управляющим терминалом сессии: без этого
            // не работают Ctrl+C и job control
            ioctl(slave_fd, TIOCSCTTY, 0);
            let _ = tcsetpgrp(&slave, getpid());
            dup2(slave_fd, 0);
            dup2(slave_fd, 1);
            dup2(slave_fd, 2);
            let argv = [arg0];
            let _ = execve(&shell_c, &argv, &env_c);
            nix::libc::_exit(127);
        },
        Err(e) => {
            drop(master);
            drop(slave);
            let _ = nix_close(write_fd);
            Err(format!("fork: {}", e))
        }
    }
}

fn pty_write_input(fd: i32, bytes: &[u8]) {
    let mut off = 0;
    while off < bytes.len() {
        let n = unsafe { libc_write(fd, bytes[off..].as_ptr().cast(), bytes.len() - off) };
        if n <= 0 {
            break;
        }
        off += n as usize;
    }
}

fn pty_resize(master_fd: i32, pid: Pid, rows: u16, cols: u16) {
    let ws = Winsize { ws_row: rows, ws_col: cols, ws_xpixel: 0, ws_ypixel: 0 };
    unsafe {
        // Константа типизирована libc под целевую платформу (c_ulong для gnu, c_int для musl)
        ioctl(master_fd, TIOCSWINSZ, &ws as *const Winsize);
    }
    let _ = kill(Pid::from_raw(-pid.as_raw()), Signal::SIGWINCH);
}

async fn write_msg(ws_tx: &mut SplitSink<WebSocket, Message>, payload: String) {
    let _ = ws_tx.send(Message::Text(payload.into())).await;
}

/// Запускает shell и регистрирует сессию (reader+waiter+скроллбек).
fn start_session() -> Result<(), String> {
    {
        let guard = TERM_SLOT.lock().unwrap();
        if let Some(s) = guard.as_ref() {
            if s.exit_code.is_none() {
                return Err("Терминал уже запущен в другой сессии".into());
            }
        }
    }

    let (master, write_fd, child_pid) = spawn_shell(30, 100)?;
    let master_fd = master.as_raw_fd();
    let (tx, _) = broadcast::channel::<Event>(512);

    // reader: вывод PTY → скроллбек + broadcast; владелец master-fd
    let tx_reader = tx.clone();
    std::thread::spawn(move || {
        let mut file = std::fs::File::from(master);
        let mut buf = [0u8; 4096];
        loop {
            match file.read(&mut buf) {
                Ok(0) => break,
                Ok(n) => {
                    let chunk = buf[..n].to_vec();
                    {
                        let mut guard = TERM_SLOT.lock().unwrap();
                        if let Some(s) = guard.as_mut() {
                            s.scrollback.extend_from_slice(&chunk);
                            if s.scrollback.len() > SCROLLBACK_CAP {
                                let excess = s.scrollback.len() - SCROLLBACK_CAP;
                                s.scrollback.drain(..excess);
                            }
                        }
                    }
                    let _ = tx_reader.send((EventKind::Chunk, chunk));
                }
                Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(_) => break, // EIO — процесс завершился
            }
        }
    });

    // waiter: waitpid → код завершения; хвост вывода добирает пауза перед Exit
    let tx_waiter = tx.clone();
    let pid_raw = child_pid.as_raw() as c_int;
    std::thread::spawn(move || {
        let mut status: c_int = 0;
        let mut code: i32 = -1;
        loop {
            let r = unsafe { waitpid(pid_raw, &mut status, WNOHANG) };
            if r == pid_raw {
                if WIFEXITED(status) {
                    code = WEXITSTATUS(status);
                }
                break;
            }
            if r == -1 {
                break;
            }
            std::thread::sleep(Duration::from_millis(150));
        }

        {
            let mut guard = TERM_SLOT.lock().unwrap();
            if let Some(s) = guard.as_mut() {
                s.exit_code = Some(code);
            }
        }
        std::thread::sleep(Duration::from_millis(300));
        let _ = tx_waiter.send((EventKind::Exit, code.to_string().into_bytes()));
    });

    *TERM_SLOT.lock().unwrap() = Some(TermSession {
        tx,
        scrollback: Vec::new(),
        master_fd,
        write_fd,
        child_pid,
        exit_code: None,
    });
    log("INFO", "Запущен интерактивный терминал".into());
    Ok(())
}

pub async fn term_ws(ws: WebSocketUpgrade, State(state): State<AppState>) -> impl IntoResponse {
    let debug = state.debug;
    ws.on_upgrade(move |socket| handle_term_socket(socket, debug))
}

async fn handle_term_socket(socket: WebSocket, debug: bool) {
    let (mut ws_tx, mut ws_rx) = socket.split();

    // Подключение к уже идущей сессии — транслируем её скроллбек
    let mut rx: Option<broadcast::Receiver<Event>> = None;
    let running = {
        let guard = TERM_SLOT.lock().unwrap();
        guard.as_ref().map_or(false, |s| s.exit_code.is_none())
    };
    if running {
        if let Some(s) = snapshot() {
            if !s.scrollback.is_empty() {
                let _ = ws_tx.send(Message::Binary(s.scrollback.into())).await;
            }
            rx = Some(s.tx.subscribe());
        }
    }

    write_msg(
        &mut ws_tx,
        format!("{{\"type\":\"status\",\"running\":{}}}", running),
    )
    .await;

    let mut ws_open = true;

    loop {
        tokio::select! {
            biased;
            event = async {
                match rx.as_mut() {
                    Some(r) => r.recv().await,
                    None => std::future::pending::<Result<Event, tokio::sync::broadcast::error::RecvError>>().await,
                }
            } => {
                match event {
                    Ok((EventKind::Chunk, chunk)) => {
                        if ws_open && ws_tx.send(Message::Binary(chunk.into())).await.is_err() {
                            ws_open = false;
                        }
                    }
                    Ok((EventKind::Exit, code_bytes)) => {
                        let code_str = String::from_utf8_lossy(&code_bytes);
                        if ws_open {
                            write_msg(&mut ws_tx, format!("{{\"type\":\"exit\",\"code\":{}}}", code_str)).await;
                        }
                        // Соединение не закрываем: клиент может перезапустить shell
                        rx = None;
                        if !ws_open {
                            break;
                        }
                    }
                    // Отстали от канала — восстанавливаемся из скроллбека
                    Err(tokio::sync::broadcast::error::RecvError::Lagged(_)) => {
                        if ws_open {
                            let scrollback = TERM_SLOT.lock().unwrap().as_ref().map(|s| s.scrollback.clone()).unwrap_or_default();
                            write_msg(&mut ws_tx, "{\"type\":\"clear\"}".into()).await;
                            let _ = ws_tx.send(Message::Binary(scrollback.into())).await;
                        }
                    }
                    Err(tokio::sync::broadcast::error::RecvError::Closed) => break,
                }
            }
            maybe_msg = ws_rx.next(), if ws_open => {
                match maybe_msg {
                    Some(Ok(Message::Binary(data))) => {
                        let bytes: Vec<u8> = data.into();
                        let fd = snapshot().filter(|s| s.exit_code.is_none()).map(|s| s.write_fd);
                        if let Some(fd) = fd {
                            let _ = tokio::task::spawn_blocking(move || pty_write_input(fd, &bytes)).await;
                        }
                    }
                    Some(Ok(Message::Text(txt))) => {
                        let v: serde_json::Value = serde_json::from_str(txt.as_str()).unwrap_or_default();
                        match v["type"].as_str() {
                            Some("start") if rx.is_none() => match start_session() {
                                Ok(()) => {
                                    if let Some(s) = snapshot() {
                                        if !s.scrollback.is_empty() {
                                            let _ = ws_tx.send(Message::Binary(s.scrollback.into())).await;
                                        }
                                        rx = Some(s.tx.subscribe());
                                    }
                                }
                                Err(e) => {
                                    write_msg(&mut ws_tx, serde_json::json!({"type": "error", "message": e}).to_string()).await;
                                }
                            },
                            Some("resize") => {
                                let cols = v["cols"].as_u64().unwrap_or(100) as u16;
                                let rows = v["rows"].as_u64().unwrap_or(30) as u16;
                                if let Some(s) = snapshot().filter(|s| s.exit_code.is_none()) {
                                    let _ = tokio::task::spawn_blocking(move || pty_resize(s.master_fd, s.child_pid, rows, cols)).await;
                                }
                            }
                            Some("kill") => {
                                if let Some(s) = snapshot().filter(|s| s.exit_code.is_none()) {
                                    log("WARN", "Сессия терминала прервана пользователем".into());
                                    let _ = kill(Pid::from_raw(-s.child_pid.as_raw()), Signal::SIGTERM);
                                    let _ = kill(s.child_pid, Signal::SIGTERM);
                                }
                            }
                            _ => {}
                        }
                    }
                    Some(Ok(Message::Close(_))) | Some(Err(_)) | None => {
                        // Клиент ушёл — shell продолжает работать, следующий
                        // визит подключится к живой сессии со скроллбеком
                        ws_open = false;
                        if rx.is_none() {
                            break;
                        }
                    }
                    _ => {}
                }
            }
        }
    }

    if debug {
        println!("{} [INFO] Term-WS disconnected", ts());
    }
}
