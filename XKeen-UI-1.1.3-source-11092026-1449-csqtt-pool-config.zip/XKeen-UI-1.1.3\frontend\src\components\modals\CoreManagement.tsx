import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Separator } from '@/components/ui/separator'
import { IconCpu, IconPlug, IconTrash } from '@tabler/icons-react'
import { useEffect, useState } from 'react'
import { apiCall } from '../../lib/api'
import { useAppContext, useModalContext } from '../../lib/store'

interface Props {
  onSwitchCore: (core: string) => void
  onOpenUpdate: (core: string) => void
}

const CORES = [
  { id: 'xray', label: 'Xray' },
  { id: 'mihomo', label: 'Mihomo' },
]

export function CoreManageModal({ onSwitchCore, onOpenUpdate }: Props) {
  const { state } = useAppContext()
  const { modals, dispatch } = useModalContext()
  const { currentCore, coreVersions, availableCores } = state
  const [xkeenInstalled, setXkeenInstalled] = useState<boolean | null>(null)
  const [csqttInstalled, setCsqttInstalled] = useState<boolean | null>(null)
  const [qwdttInstalled, setQwdttInstalled] = useState<boolean | null>(null)

  const close = () => dispatch({ type: 'SHOW_MODAL', modal: 'showCoreManageModal', show: false })
  const openInstall = () => {
    close()
    dispatch({ type: 'SHOW_MODAL', modal: 'showXkeenInstallModal', show: true })
  }
  const openCsqttInstall = () => {
    close()
    dispatch({ type: 'SHOW_MODAL', modal: 'showCsqttInstallModal', show: true })
  }
  const openCsqttConfig = () => {
    close()
    dispatch({ type: 'SHOW_MODAL', modal: 'showCsqttConfigModal', show: true })
  }
  const openQwdttInstall = () => {
    close()
    dispatch({ type: 'SHOW_MODAL', modal: 'showQwdttInstallModal', show: true })
  }
  const openCsqttUninstall = () => {
    close()
    dispatch({ type: 'SHOW_MODAL', modal: 'showCsqttUninstallModal', show: true })
  }
  const openQwdttUninstall = () => {
    close()
    dispatch({ type: 'SHOW_MODAL', modal: 'showQwdttUninstallModal', show: true })
  }

  useEffect(() => {
    if (!modals.showCoreManageModal) return
    apiCall<any>('GET', 'install/status')
      .then((d) => {
        if (d.success) {
          setXkeenInstalled(d.installed)
          setCsqttInstalled(d.csqttInstalled)
          setQwdttInstalled(d.qwdttInstalled)
        }
      })
      .catch(() => {
        setXkeenInstalled(null)
        setCsqttInstalled(null)
        setQwdttInstalled(null)
      })
  }, [modals.showCoreManageModal])

  return (
    <Dialog open={modals.showCoreManageModal} onOpenChange={(open) => !open && close()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 pb-3">
            <IconCpu size={24} className="text-chart-2" /> Управление ядром
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <span className="text-sm font-medium">XKeen</span>
              {xkeenInstalled === null ? (
                <span className="text-muted-foreground text-xs">Проверка...</span>
              ) : xkeenInstalled ? (
                <Badge variant="outline" className="rounded-sm border-none bg-green-500/10 px-2 text-xs text-green-400">
                  Установлено
                </Badge>
              ) : (
                <Badge variant="outline" className="rounded-sm border-none bg-red-500/10 px-2 text-xs text-red-400">
                  Не установлено
                </Badge>
              )}
            </div>
            <Button variant="outline" size="sm" onClick={openInstall}>
              {xkeenInstalled ? 'Переустановить' : 'Установить'}
            </Button>
          </div>

          <Separator />

          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <span className="text-sm font-medium">CSQTT</span>
              {csqttInstalled === null ? (
                <span className="text-muted-foreground text-xs">Проверка...</span>
              ) : csqttInstalled ? (
                <Badge variant="outline" className="rounded-sm border-none bg-green-500/10 px-2 text-xs text-green-400">
                  Установлено
                </Badge>
              ) : (
                <Badge variant="outline" className="rounded-sm border-none bg-red-500/10 px-2 text-xs text-red-400">
                  Не установлено
                </Badge>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {csqttInstalled && (
                <Button variant="outline" size="sm" onClick={openCsqttConfig}>
                  <IconPlug data-icon="inline-start" /> Конфигурация
                </Button>
              )}
              <Button variant="outline" size="sm" onClick={openCsqttInstall}>
                {csqttInstalled ? 'Переустановить' : 'Установить'}
              </Button>
              {csqttInstalled && (
                <Button variant="outline" size="sm" className="text-red-400 hover:bg-red-500/10 hover:text-red-300" onClick={openCsqttUninstall}>
                  <IconTrash data-icon="inline-start" /> Удалить
                </Button>
              )}
            </div>
          </div>

          <Separator />

          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <span className="text-sm font-medium">qWDTT</span>
              {qwdttInstalled === null ? (
                <span className="text-muted-foreground text-xs">Проверка...</span>
              ) : qwdttInstalled ? (
                <Badge variant="outline" className="rounded-sm border-none bg-green-500/10 px-2 text-xs text-green-400">
                  Установлено
                </Badge>
              ) : (
                <Badge variant="outline" className="rounded-sm border-none bg-red-500/10 px-2 text-xs text-red-400">
                  Не установлено
                </Badge>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button variant="outline" size="sm" onClick={openQwdttInstall}>
                {qwdttInstalled ? 'Переустановить' : 'Установить'}
              </Button>
              {qwdttInstalled && (
                <Button variant="outline" size="sm" className="text-red-400 hover:bg-red-500/10 hover:text-red-300" onClick={openQwdttUninstall}>
                  <IconTrash data-icon="inline-start" /> Удалить
                </Button>
              )}
            </div>
          </div>

          <Separator />

          {CORES.map((core, i) => {
            const isActive = currentCore === core.id
            const isInstalled = availableCores.includes(core.id)
            const version = coreVersions[core.id as keyof typeof coreVersions]

            return (
              <div key={core.id}>
                {i > 0 && <Separator className="mb-4" />}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium">{core.label}</span>
                      {isActive && (
                        <Badge variant="outline" className="rounded-sm border-none bg-green-500/10 px-2 text-xs text-green-400">
                          Активно
                        </Badge>
                      )}
                      {!isInstalled && (
                        <Badge variant="outline" className="rounded-sm border-none bg-red-500/10 px-2 text-xs text-red-400">
                          Не установлено
                        </Badge>
                      )}
                    </div>
                    {isInstalled && <p className="text-muted-foreground mt-0.5 text-xs">{version || 'Установлено'}</p>}
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {!isActive && isInstalled && (
                      <Button
                        size="sm"
                        onClick={() => {
                          close()
                          onSwitchCore(core.id)
                        }}
                      >
                        Переключить
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        close()
                        onOpenUpdate(core.id)
                      }}
                    >
                      {isInstalled ? 'Обновить' : 'Установить'}
                    </Button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </DialogContent>
    </Dialog>
  )
}
