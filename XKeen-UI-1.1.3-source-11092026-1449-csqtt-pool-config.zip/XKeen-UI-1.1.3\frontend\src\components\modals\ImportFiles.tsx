import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Spinner } from '@/components/ui/spinner'
import { IconFileUpload, IconTrash, IconUpload } from '@tabler/icons-react'
import { useCallback, useRef, useState } from 'react'
import { apiCall } from '../../lib/api'
import { useAppContext } from '../../lib/store'
import { cn } from '../../lib/utils'

interface Props {
  open: boolean
  onOpenChange: (open: boolean) => void
  onRefreshConfigs: () => Promise<unknown>
}

interface PendingFile {
  id: string
  name: string
  size: number
  target: string
  content: string
  exists: boolean
  status: 'pending' | 'uploading' | 'done' | 'error'
  error?: string
}

const MAX_FILE_SIZE = 5 * 1024 * 1024

function targetDirFor(name: string): string | null {
  const lower = name.toLowerCase()
  if (lower.endsWith('.yaml') || lower.endsWith('.yml')) return '/opt/etc/mihomo'
  if (lower.endsWith('.json')) return '/opt/etc/xray/configs'
  if (lower.endsWith('.lst')) return '/opt/etc/xkeen'
  return null
}

function formatBytes(bytes: number) {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 Б'
  const units = ['Б', 'КБ', 'МБ']
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1)
  const value = bytes / 1024 ** index
  return `${value >= 100 || index === 0 ? value.toFixed(0) : value.toFixed(1)} ${units[index]}`
}

export function ImportFilesModal({ open, onOpenChange, onRefreshConfigs }: Props) {
  const { state, showToast } = useAppContext({ includeConfigs: true })
  const close = () => onOpenChange(false)

  const configs = state.configs
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [files, setFiles] = useState<PendingFile[]>([])
  const [dragOver, setDragOver] = useState(false)
  const [uploading, setUploading] = useState(false)

  const addFiles = useCallback(
    (list: FileList | File[]) => {
      const next: PendingFile[] = []
      for (const file of Array.from(list)) {
        const dir = targetDirFor(file.name)
        if (!dir) {
          showToast(`Файл "${file.name}" пропущен: поддерживаются .yaml, .yml, .json, .lst`, 'error')
          continue
        }
        if (file.size > MAX_FILE_SIZE) {
          showToast(`Файл "${file.name}" превышает 5 МБ`, 'error')
          continue
        }
        next.push({
          id: `${file.name}-${Math.random().toString(36).slice(2)}`,
          name: file.name,
          size: file.size,
          target: `${dir}/${file.name}`,
          content: '',
          exists: configs.some((c) => c.file === `${dir}/${file.name}`),
          status: 'pending',
        })
      }
      if (next.length === 0) return

      // Читаем содержимое всех файлов и запускаем загрузку
      Promise.all(
        next.map(
          (f) =>
            new Promise<{ id: string; content: string; error?: string }>((resolve) => {
              const reader = new FileReader()
              reader.onload = () => resolve({ id: f.id, content: reader.result as string })
              reader.onerror = () => resolve({ id: f.id, content: '', error: 'Ошибка чтения файла' })
              const orig = Array.from(list).find((x) => x.name === f.name)
              if (orig) reader.readAsText(orig)
              else resolve({ id: f.id, content: '', error: 'Файл не найден' })
            })
        )
      ).then((results) => {
        setFiles((prev) => [
          ...prev,
          ...next.map((f) => {
            const r = results.find((res) => res.id === f.id)
            return { ...f, content: r?.content ?? '', error: r?.error }
          }),
        ])
      })
    },
    [configs, showToast]
  )

  const uploadAll = useCallback(async () => {
    const pending = files.filter((f) => f.status === 'pending')
    if (pending.length === 0) return
    setUploading(true)
    setFiles((prev) => prev.map((f) => (f.status === 'pending' ? { ...f, status: 'uploading' } : f)))

    for (const file of pending) {
      const result = await apiCall<{ success: boolean; error?: string }>('POST', 'configs/upload', {
        file: file.target,
        content: file.content,
        overwrite: file.exists,
      })
      setFiles((prev) =>
        prev.map((f) =>
          f.id === file.id
            ? { ...f, status: result.success ? 'done' : 'error', error: result.success ? undefined : result.error }
            : f
        )
      )
    }

    setUploading(false)
    const okCount = pending.length
    await onRefreshConfigs()
    showToast(`Импортировано файлов: ${okCount}`)
  }, [files, onRefreshConfigs, showToast])

  const failed = files.some((f) => f.status === 'error')
  const allDone = files.length > 0 && files.every((f) => f.status === 'done')
  const canUpload = files.some((f) => f.status === 'pending') && !uploading

  return (
    <Dialog open={open} onOpenChange={(o) => !o && close()}>
      <DialogContent className="flex h-[70dvh]! max-w-2xl! flex-col overflow-hidden p-4 sm:p-5">
        <DialogHeader className="shrink-0 pr-10">
          <DialogTitle className="flex items-center gap-2">
            <IconFileUpload size={24} className="text-chart-2" /> Импорт конфигураций
          </DialogTitle>
          <DialogDescription>
            Загрузка файлов config.yaml (и других конфигов) с компьютера на роутер. Поддерживаются .yaml, .yml, .json и
            .lst; файлы распределяются по директориям ядер автоматически.
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="min-h-0 flex-1">
          <div className="px-1 py-1.5 pr-3">
            <div
              className={cn(
                'flex min-h-40 cursor-pointer flex-col items-center justify-center gap-3 rounded-lg border-2 border-dashed p-6 text-center transition-colors',
                dragOver ? 'border-[#60a5fa] bg-blue-500/10' : 'border-ring/40 hover:border-[#60a5fa]'
              )}
              onClick={() => inputRef.current?.click()}
              onDragOver={(e) => {
                e.preventDefault()
                setDragOver(true)
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault()
                setDragOver(false)
                if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files)
              }}
            >
              <IconUpload size={32} className="text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Перетащите файлы сюда</p>
                <p className="text-muted-foreground mt-1 text-xs">или нажмите для выбора с компьютера</p>
              </div>
              <p className="text-muted-foreground/70 text-[11px]">
                .yaml / .yml → Mihomo · .json → Xray · .lst → XKeen · до 5 МБ на файл
              </p>
              <input
                ref={inputRef}
                type="file"
                multiple
                accept=".yaml,.yml,.json,.lst"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files?.length) addFiles(e.target.files)
                  e.target.value = ''
                }}
              />
            </div>

            {files.length > 0 && (
              <div className="mt-3 space-y-1.5">
                {files.map((f) => (
                  <div key={f.id} className="bg-card flex items-center justify-between gap-3 rounded-lg border px-3 py-2">
                    <div className="flex min-w-0 flex-1 items-center gap-2">
                      <span className="truncate text-sm font-medium">{f.name}</span>
                      <Badge variant="outline" className="shrink-0 text-[10px]">
                        {formatBytes(f.size)}
                      </Badge>
                      {f.exists && (
                        <Badge variant="outline" className="shrink-0 border-none bg-amber-500/10 text-[10px] text-amber-400">
                          перезапись
                        </Badge>
                      )}
                      {f.status === 'error' && (
                        <span className="truncate text-xs text-red-400">{f.error || 'Ошибка загрузки'}</span>
                      )}
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <span className="text-muted-foreground max-w-55 truncate text-[11px]" title={f.target}>
                        {f.target}
                      </span>
                      {f.status === 'uploading' && <Spinner className="text-chart-2 size-3.5" />}
                      {f.status === 'done' && <Badge variant="outline" className="border-none bg-green-500/10 text-[10px] text-green-400">Импортирован</Badge>}
                      {(f.status === 'pending' || f.status === 'error') && !uploading && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-muted-foreground hover:text-destructive size-6"
                          aria-label={`Убрать ${f.name}`}
                          onClick={() => setFiles((prev) => prev.filter((x) => x.id !== f.id))}
                        >
                          <IconTrash className="size-3.5" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </ScrollArea>

        <div className="flex shrink-0 items-center justify-end gap-2 pt-1">
          <Button variant="outline" onClick={close} disabled={uploading}>
            {failed ? 'Закрыть' : 'Отмена'}
          </Button>
          <Button onClick={uploadAll} disabled={!canUpload}>
            {uploading ? <Spinner data-icon="inline-start" /> : <IconUpload data-icon="inline-start" />}
            {allDone ? 'Импортировать ещё' : `Импортировать${files.length ? ` (${files.filter((f) => f.status === 'pending').length})` : ''}`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
