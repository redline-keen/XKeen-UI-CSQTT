import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Spinner } from '@/components/ui/spinner'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { IconAlertTriangle, IconPlayerStopFilled, IconRefresh, IconTerminal2, IconTrash } from '@tabler/icons-react'
import { useEffect, useRef, useState } from 'react'
import '@xterm/xterm/css/xterm.css'
import { FitAddon } from '@xterm/addon-fit'
import { Terminal } from '@xterm/xterm'
import { apiCall } from '../../lib/api'
import { useModalContext } from '../../lib/store'

type InstallStatus = { installed: boolean; csqttInstalled: boolean; qwdttInstalled: boolean; running: boolean }

type InstallKind = 'xkeen' | 'csqtt' | 'qwdtt'

/** Режим: обычная установка или удаление (CSQTT/qWDTT) */
type SessionAction = 'install' | 'uninstall'

interface Props {
  onInstalled?: () => void
}

const KIND_META: Record<
  InstallKind,
  { title: string; startBtn: string; installedText: string; notInstalledText: string; stopConfirm: string; modal: 'showXkeenInstallModal' | 'showCsqttInstallModal' | 'showQwdttInstallModal' }
> = {
  xkeen: {
    title: 'Установка XKeen',
    startBtn: 'Запустить установку XKeen',
    installedText: 'XKeen уже установлен. Повторный запуск переустановит его.',
    notInstalledText: 'XKeen не обнаружен на роутере.',
    stopConfirm: 'Прервать установку XKeen? Это может оставить систему в частично установленном состоянии.',
    modal: 'showXkeenInstallModal',
  },
  csqtt: {
    title: 'Установка CSQTT',
    startBtn: 'Запустить установку CSQTT',
    installedText: 'CSQTT уже установлен. Повторный запуск переустановит его.',
    notInstalledText: 'CSQTT не обнаружен на роутере.',
    stopConfirm: 'Прервать установку CSQTT? Это может оставить систему в частично установленном состоянии.',
    modal: 'showCsqttInstallModal',
  },
  qwdtt: {
    title: 'Установка qWDTT',
    startBtn: 'Запустить установку qWDTT',
    installedText: 'qWDTT уже установлен. Повторный запуск переустановит его.',
    notInstalledText: 'qWDTT не обнаружен на роутере.',
    stopConfirm: 'Прервать установку qWDTT? Это может оставить систему в частично установленном состоянии.',
    modal: 'showQwdttInstallModal',
  },
}

/** Тексты режима удаления; XKeen из панели не удаляется */
const UNINSTALL_META: Record<string, { title: string; startBtn: string; stopConfirm: string; modal: 'showCsqttUninstallModal' | 'showQwdttUninstallModal' }> = {
  csqtt: {
    title: 'Удаление CSQTT',
    startBtn: 'Удалить CSQTT',
    stopConfirm: 'Прервать удаление CSQTT? Это может оставить систему в частично удалённом состоянии.',
    modal: 'showCsqttUninstallModal',
  },
  qwdtt: {
    title: 'Удаление qWDTT',
    startBtn: 'Удалить qWDTT',
    stopConfirm: 'Прервать удаление qWDTT? Это может оставить систему в частично удалённом состоянии.',
    modal: 'showQwdttUninstallModal',
  },
}

function InstallTerminalModal({ kind, action = 'install', onInstalled }: Props & { kind: InstallKind; action?: SessionAction }) {
  const meta = KIND_META[kind]
  const uninstallMeta = UNINSTALL_META[kind]
  const isUninstall = action === 'uninstall' && !!uninstallMeta
  const { modals, dispatch } = useModalContext()
  // Флаг видимости: у модалки удаления свой флаг, отличный от установочного
  const open = isUninstall ? modals[uninstallMeta.modal] : modals[meta.modal]
  const close = () => dispatch({ type: 'SHOW_MODAL', modal: isUninstall ? uninstallMeta.modal : meta.modal, show: false })

  const termHostRef = useRef<HTMLDivElement | null>(null)
  const termRef = useRef<Terminal | null>(null)
  const fitRef = useRef<FitAddon | null>(null)
  const wsRef = useRef<WebSocket | null>(null)
  const resizeObsRef = useRef<ResizeObserver | null>(null)
  // Команда start, отправленная до открытия WS — уходит сразу после onopen
  const pendingStartRef = useRef(false)

  const [status, setStatus] = useState<InstallStatus | null>(null)
  const [phase, setPhase] = useState<'idle' | 'installing' | 'done' | 'failed'>('idle')

  const send = (data: object) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify(data))
  }

  // Подключение к /install-ws при открытии модалки
  useEffect(() => {
    if (!open) return

    const term = new Terminal({
      cursorBlink: true,
      fontSize: 13,
      fontFamily: "'JetBrains Mono Variable', monospace",
      convertEol: false,
      scrollback: 5000,
      theme: {
        background: '#0d1117',
        foreground: '#e6edf3',
      },
    })
    const fit = new FitAddon()
    term.loadAddon(fit)
    termRef.current = term
    fitRef.current = fit

    let disposed = false
    let rafId = 0
    let timerId: ReturnType<typeof setTimeout> | undefined

    term.onData((data) => {
      // Клавиатура xterm уходит бинарным фреймом: бэкенд пишет эти байты напрямую в PTY
      if (wsRef.current?.readyState === WebSocket.OPEN) wsRef.current.send(new TextEncoder().encode(data))
    })

    const resize = () => {
      if (!termHostRef.current) return
      fit.fit()
      send({ type: 'resize', cols: term.cols, rows: term.rows })
    }
    const observer = new ResizeObserver(resize)
    resizeObsRef.current = observer

    const mountTerminal = (host: HTMLDivElement) => {
      term.open(host)
      fit.fit()
      observer.observe(host)
      send({ type: 'resize', cols: term.cols, rows: term.rows })
      term.focus()
    }

    // Портал диалога монтирует содержимое в DOM асинхронно — позже первого рендера с open=true,
    // поэтому ждём появления узла терминала, прежде чем открывать в нём xterm.
    // rAF в фоне/свёрнутой вкладке троттлится браузером до нуля, поэтому дублируем
    // ожидание setTimeout-ом
    const waitForHost = () => {
      if (disposed) return
      const host = termHostRef.current
      if (host && document.body.contains(host)) {
        mountTerminal(host)
        return
      }
      rafId = requestAnimationFrame(waitForHost)
      timerId = setTimeout(waitForHost, 100)
    }
    waitForHost()

    const wsUrl = `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/install-ws`
    const ws = new WebSocket(wsUrl)
    ws.binaryType = 'arraybuffer'
    wsRef.current = ws

    ws.onopen = () => {
      send({ type: 'resize', cols: term.cols, rows: term.rows })
      if (pendingStartRef.current) {
        pendingStartRef.current = false
        send({ type: 'start', kind })
      }
      void apiCall<InstallStatus & { success: boolean }>('GET', 'install/status').then((s) => {
        if (s.success)
          setStatus({ installed: s.installed, csqttInstalled: s.csqttInstalled, qwdttInstalled: s.qwdttInstalled, running: s.running })
      })
    }

    ws.onmessage = (event) => {
      if (typeof event.data === 'string') {
        try {
          const msg = JSON.parse(event.data)
          if (msg.type === 'status') {
            setStatus({ installed: msg.installed, csqttInstalled: msg.csqttInstalled, qwdttInstalled: msg.qwdttInstalled, running: msg.running })
            if (msg.running) setPhase('installing')
          } else if (msg.type === 'clear') {
            term.clear()
          } else if (msg.type === 'error') {
            term.write(`\r\n\x1b[31m✖ ${msg.message}\x1b[0m\r\n`)
          } else if (msg.type === 'exit') {
            setPhase(msg.code === 0 ? 'done' : 'failed')
          }
        } catch {
          /* ignore */
        }
      } else {
        const bytes = new Uint8Array(event.data as ArrayBuffer)
        term.write(bytes)
      }
    }

    ws.onclose = () => {
      // Пишем только в живой терминал: после закрытия модалки term уже disposed
      if (termRef.current) {
        termRef.current.write('\r\n\x1b[90mСоединение с терминалом потеряно\x1b[0m\r\n')
      }
    }

    return () => {
      disposed = true
      cancelAnimationFrame(rafId)
      clearTimeout(timerId)
      observer.disconnect()
      ws.onopen = ws.onclose = ws.onerror = ws.onmessage = null
      if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) ws.close()
      wsRef.current = null
      resizeObsRef.current = null
      pendingStartRef.current = false
      term.dispose()
      termRef.current = null
      fitRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const startInstall = () => {
    if (phase === 'installing') return
    if (isUninstall && !confirm(`Удалить ${meta.title.replace('Установка ', '')} с роутера? Служба будет остановлена, конфигурация удалена.`)) return
    termRef.current?.reset()
    setPhase('installing')
    const msg: object = isUninstall ? { type: 'start', kind, action: 'uninstall' } : { type: 'start', kind }
    if (wsRef.current?.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify(msg))
    else pendingStartRef.current = true
    // Установщик сразу задаёт вопросы — фокусируем терминал, чтобы ввод шёл без клика
    termRef.current?.focus()
  }

  const stopInstall = () => {
    if (phase !== 'installing') return
    if (!confirm(isUninstall ? uninstallMeta.stopConfirm : meta.stopConfirm)) return
    send({ type: 'kill' })
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && close()}>
      <DialogContent className="flex h-[85dvh]! max-w-4xl! flex-col overflow-hidden p-4 sm:p-5">
        <DialogHeader className="shrink-0 pr-10">
          <DialogTitle className="flex items-center gap-2">
            {isUninstall ? (
              <IconTrash size={24} className="text-red-400" />
            ) : (
              <IconTerminal2 size={24} className="text-chart-2" />
            )}{' '}
            {isUninstall ? uninstallMeta.title : meta.title}
          </DialogTitle>
          <DialogDescription>
            {isUninstall
              ? 'Удаление выполняется штатным деинсталлятором в встроенном терминале: остановка службы, очистка автозапуска, cron и конфигурации.'
              : 'Интерактивный установщик в встроенном терминале. Следуйте инструкциям на экране — ввод с клавиатуры передаётся в терминал роутера.'}
          </DialogDescription>
        </DialogHeader>

        <div className="bg-card min-h-0 flex-1 overflow-hidden rounded-lg border">
          <div ref={termHostRef} className="h-full w-full p-2" />
        </div>

        <div className="flex shrink-0 flex-wrap items-center justify-between gap-2 pt-1">
          <div className="text-muted-foreground flex items-center gap-2 text-xs">
            {phase === 'installing' && (
              <span className="flex items-center gap-1.5">
                <Spinner className="text-chart-2 size-3.5" /> {isUninstall ? 'Идёт удаление...' : 'Идёт установка...'}
              </span>
            )}
            {phase === 'idle' && status === null && 'Проверка состояния...'}
            {phase === 'idle' && status !== null && !status.running && (
              <span>
                {isUninstall
                  ? `${meta.title.replace('Установка ', '')} будет полностью удалён с роутера.`
                  : kindInstalled(status, kind)
                    ? meta.installedText
                    : meta.notInstalledText}
              </span>
            )}
            {phase === 'idle' && status !== null && status.running && 'Установка уже выполняется — подключение к терминалу...'}
            {phase === 'done' && <span className="text-green-400">{isUninstall ? 'Удаление завершено' : 'Установка завершена'}</span>}
            {phase === 'failed' && (
              <span className="flex items-center gap-1.5 text-red-400">
                <IconAlertTriangle size={14} /> {isUninstall ? 'Удаление прервано или завершилось с ошибкой' : 'Установка прервана или завершилась с ошибкой'}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {phase === 'installing' ? (
              <Button variant="destructive" size="sm" onClick={stopInstall}>
                <IconPlayerStopFilled data-icon="inline-start" /> Прервать
              </Button>
            ) : phase === 'idle' && status !== null && status.running ? (
              <span className="text-muted-foreground text-xs">Терминал занят текущей установкой</span>
            ) : (
              <>
                {(phase === 'done' || phase === 'failed') && (
                  <TooltipProvider delayDuration={400}>
                    <Tooltip>
                      <TooltipTrigger
                        render={
                          <Button variant="outline" size="sm" onClick={startInstall}>
                            <IconRefresh data-icon="inline-start" /> Повторить
                          </Button>
                        }
                      />
                      <TooltipContent>{isUninstall ? 'Запустить удаление заново' : 'Запустить установку заново'}</TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
                <Button
                  variant={isUninstall && phase !== 'done' && phase !== 'failed' ? 'destructive' : undefined}
                  size="sm"
                  onClick={() => {
                    if (phase === 'idle') startInstall()
                    else {
                      if (phase === 'done') onInstalled?.()
                      close()
                    }
                  }}
                >
                  {phase === 'done' ? 'Готово' : phase === 'failed' ? 'Закрыть' : isUninstall ? uninstallMeta.startBtn : meta.startBtn}
                </Button>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function kindInstalled(status: InstallStatus, kind: InstallKind): boolean {
  if (kind === 'csqtt') return status.csqttInstalled
  if (kind === 'qwdtt') return status.qwdttInstalled
  return status.installed
}

export function XkeenInstallModal(props: Props) {
  return <InstallTerminalModal kind="xkeen" {...props} />
}

export function CsqttInstallModal(props: Props) {
  return <InstallTerminalModal kind="csqtt" {...props} />
}

export function QwdttInstallModal(props: Props) {
  return <InstallTerminalModal kind="qwdtt" {...props} />
}

export function CsqttUninstallModal(props: Props) {
  return <InstallTerminalModal kind="csqtt" action="uninstall" {...props} />
}

export function QwdttUninstallModal(props: Props) {
  return <InstallTerminalModal kind="qwdtt" action="uninstall" {...props} />
}
